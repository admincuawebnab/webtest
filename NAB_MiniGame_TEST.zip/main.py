"""
Bot Discord - Cửa Hàng + Điểm Danh + Mua Hàng + Tặng Xu + Lịch Sử Đơn Hàng
--------------------------------------------------------------------------
Cần cài:  pip install discord.py python-dotenv

Chạy:     python main.py

Các lệnh:
  /cuahang             - xem danh sách sản phẩm (id, tên, giá)
  /dnhn                - điểm danh hằng ngày, nhận 2-8 xu
  /muasp id soluong    - mua sản phẩm theo id (admin nhận DM có nút Done/Từ chối)
  /checkxu             - xem số xu hiện có
  /checkbot            - xem trạng thái + giờ hiện tại + uptime của bot
  /lsmua               - xem lịch sử các đơn đã mua
  /tangxu user soluong - CHỈ ADMIN dùng, tặng xu cho thành viên
"""

import json
import os
import random
import re
import string
import uuid
from datetime import datetime, timedelta, timezone

import discord
from discord import app_commands
from discord.ext import commands, tasks
from dotenv import load_dotenv

# ============ CẤU HÌNH ============
load_dotenv()
TOKEN = os.getenv("DISCORD_TOKEN")
ADMIN_ID = os.getenv("ADMIN_ID")  # ID Discord của bạn (admin) - để nhận thông báo & dùng /tangxu
STATUS_CHANNEL_ID = os.getenv("STATUS_CHANNEL_ID")  # ID kênh hiện trạng thái bot (xanh/đỏ)
CLEAN_CHANNEL_ID = os.getenv("CLEAN_CHANNEL_ID")  # ID kênh chỉ cho phép dùng lệnh, tự xóa tin nhắn thường (trừ admin)
LOG_NAPXU_CHANNEL_ID = os.getenv("LOG_NAPXU_CHANNEL_ID")  # ID kênh log các đơn nạp xu thành công
LOG_SANPHAM_CHANNEL_ID = os.getenv("LOG_SANPHAM_CHANNEL_ID")  # ID kênh log các đơn sản phẩm thành công
MEMBER_COUNT_CHANNEL_ID = os.getenv("MEMBER_COUNT_CHANNEL_ID")  # ID kênh tự cập nhật tổng thành viên

TEN_KENH_ONLINE = "🟢┃nab-on"
TEN_KENH_OFFLINE = "🔴┃nab-off"

SHOP_FILE = "shop.json"
ECONOMY_FILE = "economy.json"
ORDERS_FILE = "orders.json"
EVENTS_FILE = "events.json"
TONKHO_FILE = "tonkho.json"
NOTES_FILE = "notes.json"
CODES_FILE = "codes.json"
BANNED_FILE = "banned.json"
NAPTHE_FILE = "napthe.json"
NAPBANK_FILE = "napbank.json"
THONGBAO_FILE = "thongbao.json"
ADMINS_FILE = "admins.json"
MINIGAME_FILE = "memory_games.json"

# Mini Game Memory: cooldown dùng chung cho cả 2 mức = 12 giờ.
MINIGAME_COOLDOWN_SECONDS = 12 * 60 * 60
MINIGAME_GAME_TTL_SECONDS = 30 * 60
MINIGAME_LOCK = Lock()

XU_MIN = 2   # số xu tối thiểu khi điểm danh
XU_MAX = 15 # số xu tối đa khi điểm danh

intents = discord.Intents.default()
intents.members = True
bot = commands.Bot(command_prefix="!", intents=intents)

THOI_GIAN_BAT_DAU = datetime.now(timezone.utc)  # thời điểm bot bắt đầu chạy, dùng để tính uptime

NHAN_TRANG_THAI = {
    "cho_xu_ly": "⏳ Chờ xử lý",
    "hoan_thanh": "✅ Hoàn thành",
    "tu_choi": "❌ Đã từ chối",
}


# ============ HÀM TIỆN ÍCH ĐỌC/GHI FILE ============
def doc_json(duong_dan, mac_dinh):
    """Đọc file JSON, nếu chưa có thì tạo file với dữ liệu mặc định."""
    if not os.path.exists(duong_dan):
        ghi_json(duong_dan, mac_dinh)
        return mac_dinh
    with open(duong_dan, "r", encoding="utf-8") as f:
        return json.load(f)


def ghi_json(duong_dan, du_lieu):
    with open(duong_dan, "w", encoding="utf-8") as f:
        json.dump(du_lieu, f, ensure_ascii=False, indent=2)


def lay_thong_tin_user(du_lieu_economy, user_id):
    return du_lieu_economy.get(user_id, {"xu": 0, "lan_diem_danh_cuoi": None})


def tim_san_pham_theo_id(ma_id):
    du_lieu_shop = doc_json(SHOP_FILE, {"products": []})
    for sp in du_lieu_shop.get("products", []):
        if str(sp.get("id")) == str(ma_id):
            return sp
    return None


def la_admin(user_id: int) -> bool:
    danh_sach_admin = doc_json(ADMINS_FILE, [])

    if ADMIN_ID and str(user_id) == str(ADMIN_ID):
        return True

    return str(user_id) in [str(x) for x in danh_sach_admin]


def la_bi_cam(user_id) -> bool:
    du_lieu = doc_json(BANNED_FILE, {})
    return str(user_id) in du_lieu


def lay_id_note_moi(du_lieu_notes):
    """Tạo mã note 6 ký tự (3 chữ cái + 3 số), đảm bảo không trùng với note nào đã có."""
    id_da_dung = set()
    for danh_sach in du_lieu_notes.values():
        for note_item in danh_sach:
            id_da_dung.add(note_item.get("id"))

    while True:
        chu_cai = "".join(random.choices(string.ascii_uppercase, k=3))
        so = "".join(random.choices(string.digits, k=3))
        ma_moi = chu_cai + so
        if ma_moi not in id_da_dung:
            return ma_moi


def lay_id_don_moi(danh_sach_don):
    id_da_dung = {str(don.get("id")) for don in danh_sach_don}
    while True:
        ma_moi = str(random.randint(100, 9999))
        if ma_moi not in id_da_dung:
            return ma_moi


def tim_don_theo_id(danh_sach_don, ma_don):
    for don in danh_sach_don:
        if str(don.get("id")) == str(ma_don):
            return don
    return None


def lay_phien_diem_danh(gio_vn: datetime):
    """Tính mã phiên điểm danh hiện tại, mốc reset là 7:00 sáng giờ VN mỗi ngày.
    Trả về (ma_phien, thoi_gian_reset_tiep_theo)."""
    moc_7h_hom_nay = gio_vn.replace(hour=7, minute=0, second=0, microsecond=0)
    if gio_vn >= moc_7h_hom_nay:
        ma_phien = gio_vn.strftime("%Y-%m-%d")
        thoi_gian_reset_tiep = moc_7h_hom_nay + timedelta(days=1)
    else:
        ma_phien = (gio_vn - timedelta(days=1)).strftime("%Y-%m-%d")
        thoi_gian_reset_tiep = moc_7h_hom_nay
    return ma_phien, thoi_gian_reset_tiep


def parse_thoigian(chuoi: str):
    """Đổi chuỗi kiểu '30m', '1h', '2day' thành timedelta. Trả về None nếu sai định dạng."""
    khop = re.match(r"^(\d+)\s*(s|giay|m|ph|h|gio|d|day|ngay)$", chuoi.strip().lower())
    if not khop:
        return None
    so = int(khop.group(1))
    don_vi = khop.group(2)
    if don_vi in ("s", "giay"):
        return timedelta(seconds=so)
    if don_vi in ("m", "ph"):
        return timedelta(minutes=so)
    if don_vi in ("h", "gio"):
        return timedelta(hours=so)
    if don_vi in ("d", "day", "ngay"):
        return timedelta(days=so)
    return None


# ============ FORM NHẬP GHI CHÚ KHI HOÀN THÀNH ĐƠN HÀNG ============
class HoanThanhDonModal(discord.ui.Modal, title="Hoàn Thành Đơn Hàng"):
    ghichu = discord.ui.TextInput(
        label="Nội dung gửi cho khách (code, tài khoản...)",
        style=discord.TextStyle.paragraph,
        placeholder="VD: Tài khoản: abc@gmail.com | Mật khẩu: 123456",
        max_length=4000,
        required=False,
    )

    def __init__(self, goc_message: discord.Message):
        super().__init__()
        self.goc_message = goc_message

    async def on_submit(self, interaction: discord.Interaction):
        await xu_ly_hoan_thanh_don_hang(interaction, self.goc_message, self.ghichu.value)


# ============ NÚT BẤM XỬ LÝ ĐƠN HÀNG (Done / Từ chối) ============
class OrderActionView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)

    @discord.ui.button(label="Hoàn thành", style=discord.ButtonStyle.success, custom_id="order_done", emoji="✅")
    async def nut_hoan_thanh(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not la_admin(interaction.user.id):
            await interaction.response.send_message("❌ Bạn không có quyền bấm nút này.", ephemeral=True)
            return
        await interaction.response.send_modal(HoanThanhDonModal(interaction.message))

    @discord.ui.button(label="Từ chối", style=discord.ButtonStyle.danger, custom_id="order_reject", emoji="❌")
    async def nut_tu_choi(self, interaction: discord.Interaction, button: discord.ui.Button):
        await xu_ly_nut_don_hang(interaction, "tu_choi")


async def xu_ly_nut_don_hang(interaction: discord.Interaction, hanh_dong: str):
    if not la_admin(interaction.user.id):
        await interaction.response.send_message("❌ Bạn không có quyền bấm nút này.", ephemeral=True)
        return

    if not interaction.message.embeds:
        await interaction.response.send_message("Không đọc được thông tin đơn hàng.", ephemeral=True)
        return

    embed_cu = interaction.message.embeds[0]
    footer_text = embed_cu.footer.text or ""
    try:
        ma_don = footer_text.split(":")[-1].strip()
    except Exception:
        await interaction.response.send_message("Không đọc được ID đơn hàng.", ephemeral=True)
        return

    du_lieu_don = doc_json(ORDERS_FILE, {"orders": []})
    danh_sach_don = du_lieu_don.get("orders", [])
    don = tim_don_theo_id(danh_sach_don, ma_don)

    if not don:
        await interaction.response.send_message("Không tìm thấy đơn hàng này.", ephemeral=True)
        return

    if don.get("trang_thai") != "cho_xu_ly":
        await interaction.response.send_message(
            f"Đơn này đã được xử lý rồi (trạng thái: {NHAN_TRANG_THAI.get(don.get('trang_thai'), '?')}).",
            ephemeral=True,
        )
        return

    nguoi_mua_id = str(don.get("nguoi_mua_id"))
    thoi_gian_xu_ly = (datetime.now(timezone.utc) + timedelta(hours=7)).strftime("%H:%M:%S ngày %d/%m/%Y")

    du_lieu_economy = doc_json(ECONOMY_FILE, {})
    thong_tin_user = lay_thong_tin_user(du_lieu_economy, nguoi_mua_id)
    thong_tin_user["xu"] = thong_tin_user.get("xu", 0) + don.get("tong_tien", 0)
    du_lieu_economy[nguoi_mua_id] = thong_tin_user
    ghi_json(ECONOMY_FILE, du_lieu_economy)

    don["trang_thai"] = "tu_choi"
    mau = discord.Color.red()
    dong_them = f"❌ **Đã từ chối** bởi admin. Đã hoàn lại **{don.get('tong_tien', 0):,} Bxu 🪙**."
    tin_nhan_dm = (
        f"❌ **Đơn hàng #{don.get('id')} đã bị từ chối!**\n"
        f"Sản phẩm: **{don.get('ten_san_pham')}** (x{don.get('so_luong')})\n"
        f"Đã hoàn lại **{don.get('tong_tien', 0):,} Bxu 🪙** vào tài khoản của bạn.\n"
        f"Thời gian xử lý: {thoi_gian_xu_ly} (giờ VN)"
    )

    ghi_json(ORDERS_FILE, du_lieu_don)

    embed_moi = embed_cu.copy()
    embed_moi.color = mau
    embed_moi.add_field(name="Kết quả", value=dong_them, inline=False)

    view_moi = OrderActionView()
    for item in view_moi.children:
        item.disabled = True

    await interaction.response.edit_message(embed=embed_moi, view=view_moi)

    try:
        nguoi_mua = await bot.fetch_user(int(nguoi_mua_id))
        await nguoi_mua.send(tin_nhan_dm)
    except Exception as e:
        print(f"Không gửi được DM cho người mua: {e}")


# ============ XỬ LÝ HOÀN THÀNH ĐƠN HÀNG (kèm ghi chú gửi khách) ============
async def xu_ly_hoan_thanh_don_hang(interaction: discord.Interaction, goc_message: discord.Message, ghi_chu: str):
    if not goc_message.embeds:
        await interaction.response.send_message("Không đọc được thông tin đơn hàng.", ephemeral=True)
        return

    embed_cu = goc_message.embeds[0]
    footer_text = embed_cu.footer.text or ""
    try:
        ma_don = footer_text.split(":")[-1].strip()
    except Exception:
        await interaction.response.send_message("Không đọc được ID đơn hàng.", ephemeral=True)
        return

    du_lieu_don = doc_json(ORDERS_FILE, {"orders": []})
    danh_sach_don = du_lieu_don.get("orders", [])
    don = tim_don_theo_id(danh_sach_don, ma_don)

    if not don:
        await interaction.response.send_message("Không tìm thấy đơn hàng này.", ephemeral=True)
        return

    if don.get("trang_thai") != "cho_xu_ly":
        await interaction.response.send_message(
            f"Đơn này đã được xử lý rồi (trạng thái: {NHAN_TRANG_THAI.get(don.get('trang_thai'), '?')}).",
            ephemeral=True,
        )
        return

    nguoi_mua_id = str(don.get("nguoi_mua_id"))
    thoi_gian_xu_ly = (datetime.now(timezone.utc) + timedelta(hours=7)).strftime("%H:%M:%S ngày %d/%m/%Y")

    don["trang_thai"] = "hoan_thanh"
    don["ghi_chu_giao_hang"] = ghi_chu or ""
    ghi_json(ORDERS_FILE, du_lieu_don)

    embed_moi = embed_cu.copy()
    embed_moi.color = discord.Color.green()
    embed_moi.add_field(name="Kết quả", value="✅ **Đã xử lý xong** bởi admin.", inline=False)
    if ghi_chu:
        embed_moi.add_field(name="📋 Nội dung đã gửi khách", value=f"```{ghi_chu[:1000]}```", inline=False)

    view_moi = OrderActionView()
    for item in view_moi.children:
        item.disabled = True
    await goc_message.edit(embed=embed_moi, view=view_moi)

    await interaction.response.send_message("✅ Đã hoàn thành đơn hàng và gửi nội dung cho khách!", ephemeral=True)

    if LOG_SANPHAM_CHANNEL_ID:
        try:
            kenh_log = bot.get_channel(int(LOG_SANPHAM_CHANNEL_ID)) or await bot.fetch_channel(int(LOG_SANPHAM_CHANNEL_ID))
            embed_log = discord.Embed(title="🛍️ ĐƠN HÀNG THÀNH CÔNG", color=discord.Color.green())
            embed_log.add_field(name="🆔 Mã đơn hàng", value=f"`{don.get('id')}`", inline=False)
            embed_log.add_field(name="👤 Người mua", value=f"<@{nguoi_mua_id}>", inline=False)
            embed_log.add_field(name="📦 Sản phẩm", value=f"{don.get('ten_san_pham')} (x{don.get('so_luong')})", inline=True)
            embed_log.add_field(name="💰 Tổng tiền", value=f"{don.get('tong_tien', 0):,} Bxu 🪙", inline=True)
            embed_log.set_footer(text=thoi_gian_xu_ly)
            await kenh_log.send(content=f"<@{nguoi_mua_id}>", embed=embed_log)
        except Exception as e:
            print(f"Không gửi được log đơn sản phẩm: {e}")

    try:
        nguoi_mua = await bot.fetch_user(int(nguoi_mua_id))
        embed_khach = discord.Embed(title="🎉 Đơn Hàng Của Bạn Đã Hoàn Thành!", color=discord.Color.green())
        embed_khach.add_field(name="🆔 Mã đơn hàng", value=f"`{don.get('id')}`", inline=True)
        embed_khach.add_field(name="📦 Sản phẩm", value=f"{don.get('ten_san_pham')} (x{don.get('so_luong')})", inline=True)
        embed_khach.add_field(name="💰 Tổng tiền", value=f"{don.get('tong_tien', 0):,} Bxu 🪙", inline=True)
        if ghi_chu:
            embed_khach.add_field(name="📋 Nội dung / Thông tin nhận hàng", value=f"```{ghi_chu[:1000]}```", inline=False)
        embed_khach.set_footer(text=f"Xử lý lúc {thoi_gian_xu_ly} (giờ VN) • Nab Store")
        await nguoi_mua.send(embed=embed_khach)
    except Exception as e:
        print(f"Không gửi được DM cho người mua: {e}")


# ============ EVENT TẶNG XU (giveaway) - bền vững qua restart ============
class EventXuView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)  # không hết hạn theo thời gian chạy, tự quản lý bằng file + task

    @discord.ui.button(label="Tham gia 🎉", style=discord.ButtonStyle.success, custom_id="eventxu_join")
    async def nut_tham_gia(self, interaction: discord.Interaction, button: discord.ui.Button):
        if la_bi_cam(interaction.user.id):
            await interaction.response.send_message("🚫 Bạn đang bị cấm dùng lệnh kiếm Bxu 🪙.", ephemeral=True)
            return

        du_lieu = doc_json(EVENTS_FILE, {"events": []})
        danh_sach_event = du_lieu.get("events", [])
        su_kien = None
        for sk in danh_sach_event:
            if sk.get("message_id") == interaction.message.id:
                su_kien = sk
                break

        if not su_kien:
            await interaction.response.send_message("Không tìm thấy thông tin event này.", ephemeral=True)
            return
        if su_kien.get("da_ket_thuc"):
            await interaction.response.send_message("Event này đã kết thúc rồi.", ephemeral=True)
            return
        if la_admin(interaction.user.id):
            await interaction.response.send_message(
                "Admin không thể tham gia event của chính mình nhé.", ephemeral=True
            )
            return
        if interaction.user.id in su_kien.get("nguoi_tham_gia", []):
            await interaction.response.send_message("Bạn đã tham gia event này rồi!", ephemeral=True)
            return

        su_kien.setdefault("nguoi_tham_gia", []).append(interaction.user.id)
        ghi_json(EVENTS_FILE, du_lieu)
        await interaction.response.send_message(
            f"✅ Bạn đã tham gia! Hiện có **{len(su_kien['nguoi_tham_gia'])}** người tham gia.", ephemeral=True
        )


@tasks.loop(seconds=20)
async def kiem_tra_event_dinh_ky():
    du_lieu = doc_json(EVENTS_FILE, {"events": []})
    danh_sach_event = du_lieu.get("events", [])
    bay_gio = datetime.now(timezone.utc)
    co_thay_doi = False

    for sk in danh_sach_event:
        if sk.get("da_ket_thuc"):
            continue
        try:
            han_ket_thuc = datetime.fromisoformat(sk.get("thoi_gian_ket_thuc"))
        except Exception:
            continue
        if bay_gio < han_ket_thuc:
            continue

        nguoi_tham_gia = sk.get("nguoi_tham_gia", [])
        if nguoi_tham_gia:
            nguoi_thang_id = random.choice(nguoi_tham_gia)
            du_lieu_economy = doc_json(ECONOMY_FILE, {})
            thong_tin_user = lay_thong_tin_user(du_lieu_economy, str(nguoi_thang_id))
            thong_tin_user["xu"] = thong_tin_user.get("xu", 0) + sk.get("so_xu", 0)
            du_lieu_economy[str(nguoi_thang_id)] = thong_tin_user
            ghi_json(ECONOMY_FILE, du_lieu_economy)
            noi_dung_ket_qua = f"🎉 Chúc mừng <@{nguoi_thang_id}> đã trúng **{sk.get('so_xu'):,} Bxu 🪙**!"
        else:
            noi_dung_ket_qua = "Event đã kết thúc nhưng không có ai tham gia 😅"

        try:
            kenh = bot.get_channel(sk.get("channel_id")) or await bot.fetch_channel(sk.get("channel_id"))
            tin_nhan = await kenh.fetch_message(sk.get("message_id"))
            embed = tin_nhan.embeds[0]
            embed.color = discord.Color.dark_grey()
            embed.add_field(name="🏁 Kết quả", value=noi_dung_ket_qua, inline=False)
            view_tat = EventXuView()
            for item in view_tat.children:
                item.disabled = True
            await tin_nhan.edit(embed=embed, view=view_tat)
        except Exception as e:
            print(f"Không cập nhật được tin nhắn event: {e}")

        sk["da_ket_thuc"] = True
        co_thay_doi = True

    if co_thay_doi:
        ghi_json(EVENTS_FILE, du_lieu)

# ============ PANEL CHÍNH (embed + nút bấm) ============
PANEL_FILE = "panel.json"
PANEL_CHANNEL_ID = 1540277945992609853  # kênh cố định đặt panel


class PanelView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)  # không hết hạn, sống lại được sau khi bot restart

    @discord.ui.button(label="Cửa Hàng", style=discord.ButtonStyle.primary, emoji="🛒", custom_id="panel_cuahang")
    async def nut_cuahang(self, interaction: discord.Interaction, button: discord.ui.Button):
        await cuahang.callback(interaction)

    @discord.ui.button(label="Điểm Danh", style=discord.ButtonStyle.primary, emoji="📅", custom_id="panel_dnhn")
    async def nut_dnhn(self, interaction: discord.Interaction, button: discord.ui.Button):
        await dnhn.callback(interaction)

    @discord.ui.button(label="Check Xu", style=discord.ButtonStyle.secondary, emoji="💰", custom_id="panel_checkxu")
    async def nut_checkxu(self, interaction: discord.Interaction, button: discord.ui.Button):
        await checkxu.callback(interaction)

    @discord.ui.button(label="Lịch Sử Mua", style=discord.ButtonStyle.secondary, emoji="📜", custom_id="panel_lsmua")
    async def nut_lsmua(self, interaction: discord.Interaction, button: discord.ui.Button):
        await lsmua.callback(interaction)

    @discord.ui.button(label="Thông Tin Cá Nhân", style=discord.ButtonStyle.secondary, emoji="🪪", custom_id="panel_ttcn")
    async def nut_ttcn(self, interaction: discord.Interaction, button: discord.ui.Button):
        await ttcn.callback(interaction)

    @discord.ui.button(label="Nạp Thẻ", style=discord.ButtonStyle.success, emoji="💳", custom_id="panel_napthe", row=1)
    async def nut_napthe(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_message(
            "Dùng lệnh `/napxu_card` để chọn loại thẻ và mệnh giá nhé.", ephemeral=True
        )

    @discord.ui.button(label="Nạp Bank", style=discord.ButtonStyle.success, emoji="🏦", custom_id="panel_napbank", row=1)
    async def nut_napbank(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_modal(NapBankModal())

    @discord.ui.button(label="Nhập Code", style=discord.ButtonStyle.success, emoji="🎟️", custom_id="panel_nhapcode", row=1)
    async def nut_nhapcode(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_modal(NhapCodeModal())

    @discord.ui.button(label="Bảng Xếp Hạng", style=discord.ButtonStyle.secondary, emoji="🏆", custom_id="panel_bxh", row=1)
    async def nut_bxh(self, interaction: discord.Interaction, button: discord.ui.Button):
        await bxh.callback(interaction)


def build_panel_embed():
    embed = discord.Embed(
        title="🏪 Nab Store — Member Panel",
        description=(
            "Chào mừng đến với Nab Store!\n\n"
            "Công cụ dành cho member. Nhấn nút tương ứng để sử dụng.\n"
            "(Mọi kết quả chỉ hiện riêng cho bạn, không ai khác thấy được)\n\n"
            "🛒 **Cửa Hàng** — xem danh sách sản phẩm\n"
            "📅 **Điểm Danh** — điểm danh hằng ngày nhận Bxu 🪙\n"
            "💰 **Check Xu** — xem số Bxu 🪙 hiện có\n"
            "📜 **Lịch Sử Mua** — xem các đơn đã mua\n"
            "🪪 **Thông Tin Cá Nhân** — xem streak, hạng, tổng đơn\n"
            "💳 **Nạp Thẻ** — nạp thẻ cào quy đổi Bxu 🪙\n"
            "🏦 **Nạp Bank** — nạp Bxu 🪙 qua chuyển khoản\n"
            "🎟️ **Nhập Code** — nhập mã code nhận Bxu 🪙\n"
            "🏆 **Bảng Xếp Hạng** — top 10 thành viên nhiều Bxu 🪙 nhất"
        ),
        color=discord.Color.gold(),
    )
    embed.set_footer(text="Nab Store • Member Panel")
    embed.timestamp = datetime.now(timezone.utc)
    return embed


async def dam_bao_panel_ton_tai():
    """Đảm bảo panel luôn tồn tại ở kênh cố định.
    Nếu đã gửi trước đó (còn lưu message_id) -> chỉ cập nhật lại nội dung/nút.
    Nếu chưa từng gửi hoặc tin nhắn cũ đã bị xóa -> gửi tin nhắn mới."""
    du_lieu = doc_json(PANEL_FILE, {})
    kenh = bot.get_channel(PANEL_CHANNEL_ID) or await bot.fetch_channel(PANEL_CHANNEL_ID)

    message_id_cu = du_lieu.get("message_id")
    if message_id_cu:
        try:
            tin_nhan = await kenh.fetch_message(message_id_cu)
            await tin_nhan.edit(embed=build_panel_embed(), view=PanelView())
            return  # đã có sẵn, cập nhật xong, không cần gửi mới
        except discord.NotFound:
            pass  # tin nhắn cũ bị xóa rồi -> gửi mới bên dưới
        except Exception as e:
            print(f"Không sửa được panel cũ, sẽ gửi panel mới: {e}")

    tin_nhan_moi = await kenh.send(embed=build_panel_embed(), view=PanelView())
    ghi_json(PANEL_FILE, {"message_id": tin_nhan_moi.id, "channel_id": kenh.id})


# ============ LỆNH /panel (gửi/refresh panel thủ công nếu cần) ============
@bot.tree.command(name="panel", description="[CHỈ ADMIN] Gửi hoặc làm mới Member Panel ở kênh cố định")
async def panel(interaction: discord.Interaction):
    if not la_admin(interaction.user.id):
        await interaction.response.send_message("❌ Bạn không có quyền dùng lệnh này.", ephemeral=True)
        return
    await interaction.response.defer(ephemeral=True)
    await dam_bao_panel_ton_tai()
    await interaction.followup.send("✅ Panel đã sẵn sàng ở kênh cố định!", ephemeral=True)


# ============ MODAL NHẬP CODE (dùng riêng cho nút bấm) ============
class NhapCodeModal(discord.ui.Modal, title="Nhập Mã Code"):
    ma = discord.ui.TextInput(label="Mã code", placeholder="Nhập mã code bạn có", required=True)

    async def on_submit(self, interaction: discord.Interaction):
        await nhapcode.callback(interaction, ma=self.ma.value)


async def cap_nhat_kenh_trang_thai(ten_moi: str):
    if not STATUS_CHANNEL_ID:
        return
    try:
        kenh = bot.get_channel(int(STATUS_CHANNEL_ID)) or await bot.fetch_channel(int(STATUS_CHANNEL_ID))
        if kenh.name != ten_moi:
            await kenh.edit(name=ten_moi)
    except Exception as e:
        print(f"Không đổi được tên kênh trạng thái: {e}")


        # ============ KIỂM TRA TOÀN CỤC: CHẶN TẤT CẢ LỆNH NẾU BỊ BAN ============
        async def kiem_tra_ban_truoc_moi_lenh(interaction: discord.Interaction) -> bool:
            """Chạy trước MỌI lệnh /. Nếu user bị ban -> chặn lệnh, không cho chạy tiếp."""
            if la_bi_cam(interaction.user.id):
                du_lieu = doc_json(BANNED_FILE, {})
                thong_tin_ban = du_lieu.get(str(interaction.user.id), {})
                ly_do = thong_tin_ban.get("ly_do", "Không có lý do")
                await interaction.response.send_message(
                    f"🚫 Bạn đã bị cấm sử dụng bot.\nLý do: {ly_do}", ephemeral=True
                )
                return False
            return True
        bot.tree.interaction_check = kiem_tra_ban_truoc_moi_lenh

        
# ============ TỰ ĐỘNG XÓA TIN NHẮN TRONG KÊNH CHỈ DÙNG LỆNH ============
@bot.event
async def on_message(message: discord.Message):
    if message.author.bot:
        return  # bỏ qua tin nhắn của chính bot

    if CLEAN_CHANNEL_ID and str(message.channel.id) == str(CLEAN_CHANNEL_ID):
        if not la_admin(message.author.id):
            try:
                await message.delete()
            except Exception as e:
                print(f"Không xóa được tin nhắn: {e}")


# ============ SỰ KIỆN BOT SẴN SÀNG ============
@bot.event
async def on_ready():
    bot.add_view(OrderActionView())  # đăng ký lại nút bấm để hoạt động cả sau khi bot khởi động lại
    bot.add_view(EventXuView())  # đăng ký lại nút "Tham gia" event để hoạt động cả sau khi bot khởi động lại
    bot.add_view(NapTheActionView())  # đăng ký lại nút xử lý yêu cầu nạp thẻ
    bot.add_view(NapBankActionView())  # đăng ký lại nút xử lý yêu cầu nạp bank
    if not kiem_tra_event_dinh_ky.is_running():
        kiem_tra_event_dinh_ky.start()
    try:
        synced = await bot.tree.sync()
        print(f"Đã đồng bộ {len(synced)} lệnh slash.")
    except Exception as e:
        print(f"Lỗi khi đồng bộ lệnh: {e}")
    print(f"Bot đã đăng nhập: {bot.user}")
    if not ADMIN_ID:
        print("⚠️  Chưa cấu hình ADMIN_ID trong Secrets. Lệnh /tangxu sẽ không dùng được và bạn sẽ không nhận thông báo mua hàng.")
    if not STATUS_CHANNEL_ID:
        print("⚠️  Chưa cấu hình STATUS_CHANNEL_ID trong Secrets. Kênh trạng thái sẽ không tự đổi màu.")
    if not CLEAN_CHANNEL_ID:
        print("⚠️  Chưa cấu hình CLEAN_CHANNEL_ID trong Secrets. Sẽ không tự xóa tin nhắn ở kênh nào cả.")
    await cap_nhat_kenh_trang_thai(TEN_KENH_ONLINE)
    await dam_bao_panel_ton_tai()


# ============ LỆNH /help (hướng dẫn sử dụng) ============
@bot.tree.command(name="help", description="Xem hướng dẫn các lệnh của bot")
async def help_command(interaction: discord.Interaction):
    embed = discord.Embed(
        title="📖 Hướng Dẫn Sử Dụng Bot",
        description="Danh sách các lệnh bạn có thể dùng:",
        color=discord.Color.blurple(),
    )
    embed.add_field(
        name="🛒 /cuahang",
        value="Xem danh sách sản phẩm đang bán, kèm giá và ID sản phẩm.",
        inline=False,
    )
    embed.add_field(
        name="📅 /dnhn",
        value="Điểm danh hằng ngày, nhận Bxu 🪙 tăng dần theo streak (chuỗi ngày liên tiếp). Reset lúc 7:00 sáng mỗi ngày, bỏ lỡ 1 ngày là mất streak.",
        inline=False,
    )
    embed.add_field(
        name="🛍️ /muasp id soluong",
        value="Mua sản phẩm theo ID (xem ID trong /cuahang). Ví dụ: `/muasp id:01 soluong:1`. Admin sẽ xử lý đơn sau khi bạn mua.",
        inline=False,
    )
    embed.add_field(
        name="💰 /checkxu",
        value="Xem số Bxu 🪙 bạn đang có.",
        inline=False,
    )
    embed.add_field(
        name="📜 /lsmua",
        value="Xem lại lịch sử các đơn hàng bạn đã mua, gồm trạng thái xử lý.",
        inline=False,
    )
    embed.add_field(
        name="🪪 /ttcn",
        value="Xem thẻ thông tin cá nhân: số Bxu 🪙, streak điểm danh, hạng trong BXH, tổng số đơn đã mua.",
        inline=False,
    )
    embed.add_field(
        name="📝 /note",
        value="Ghi chú lại điều gì đó cho riêng bạn. Đặt thêm mật khẩu (không bắt buộc) nếu muốn cho người khác xem qua /xemnote.",
        inline=False,
    )
    embed.add_field(
        name="📒 /luutrunote",
        value="Xem lại các ghi chú bạn đã lưu.",
        inline=False,
    )
    embed.add_field(
        name="🔓 /xemnote",
        value="Xem ghi chú của người khác nếu biết mã + mật khẩu đúng.",
        inline=False,
    )
    embed.add_field(
        name="🎟️ /nhapcode ma",
        value="Nhập mã code admin tung ra để nhận Bxu 🪙 (mỗi mã chỉ dùng được 1 lần/người, có thời hạn).",
        inline=False,
    )
    embed.add_field(
        name="💳 /napxu_card",
        value="Nạp thẻ cào để quy đổi ra Bxu 🪙 (chọn nhà mạng + mệnh giá, sau đó nhập mã thẻ & seri). Admin sẽ kiểm tra và cộng Bxu 🪙.",
        inline=False,
    )
    embed.add_field(
        name="🏦 /napxu_bank",
        value="Nạp Bxu 🪙 qua chuyển khoản ngân hàng (điền số tiền muốn nạp). Admin sẽ kiểm tra và cộng Bxu 🪙.",
        inline=False,
    )
    embed.add_field(
        name="🏆 /bxh",
        value="Xem bảng xếp hạng top 10 thành viên nhiều Bxu 🪙 nhất.",
        inline=False,
    )
    embed.add_field(
        name="🤖 /checkbot",
        value="Xem trạng thái hoạt động, giờ hiện tại và thời gian bot đã chạy liên tục.",
        inline=False,
    )
    embed.set_footer(text="Có thắc mắc gì cứ hỏi admin nhé!")
    await interaction.response.send_message(embed=embed, ephemeral=True)


# ============ LỆNH /cuahang ============
@bot.tree.command(name="cuahang", description="Xem danh sách sản phẩm trong cửa hàng")
async def cuahang(interaction: discord.Interaction):
    du_lieu = doc_json(SHOP_FILE, {"products": []})
    san_pham = du_lieu.get("products", [])
    ton_kho = doc_json(TONKHO_FILE, {})

    if not san_pham:
        await interaction.response.send_message("Cửa hàng hiện chưa có sản phẩm nào.")
        return

    embed = discord.Embed(
        title="🛒 Cửa Hàng",
        description="Danh sách sản phẩm đang bán:",
        color=discord.Color.gold(),
    )

    for sp in san_pham:
        ma_id = sp.get("id", "?")
        ten = sp.get("ten", "Không tên")
        gia = sp.get("gia", 0)
        mo_ta = sp.get("mo_ta", "")
        noi_dung = f"💰 Giá: **{gia:,}** Bxu 🪙\n🆔 ID: `{ma_id}`"

        so_luong_con = ton_kho.get(str(ma_id))
        if so_luong_con is not None:
            if so_luong_con <= 0:
                trang_thai = "🔴 Hết hàng"
            elif so_luong_con <= 5:
                trang_thai = f"🟡 Còn **{so_luong_con}** (sắp hết)"
            else:
                trang_thai = f"🟢 Còn **{so_luong_con}**"
            noi_dung += f"\n📦 Số lượng: {trang_thai}"

        if mo_ta:
            noi_dung += f"\n📝 {mo_ta}"
        embed.add_field(name=f"{ten}", value=noi_dung, inline=False)

    embed.set_footer(text="Dùng /muasp id: <id> soluong: <số lượng> để mua.")
    await interaction.response.send_message(embed=embed)


# ============ LỆNH /dnhn (điểm danh hằng ngày) ============
def tinh_xu_theo_streak(streak: int) -> int:
    """Streak càng dài, xu càng nhiều. Trung bình ~600 xu sau 30 ngày liên tục."""
    if streak <= 10:
        return random.randint(2, 8)
    elif streak <= 20:
        return random.randint(10, 20)
    else:
        return random.randint(30, 50)


@bot.tree.command(name="dnhn", description="Điểm danh hằng ngày để nhận Bxu 🪙")
async def dnhn(interaction: discord.Interaction):
    if la_bi_cam(interaction.user.id):
        await interaction.response.send_message("🚫 Bạn đang bị cấm dùng lệnh kiếm Bxu 🪙.", ephemeral=True)
        return

    du_lieu = doc_json(ECONOMY_FILE, {})
    user_id = str(interaction.user.id)
    bay_gio = datetime.now(timezone.utc)
    gio_vn = bay_gio + timedelta(hours=7)

    thong_tin_user = lay_thong_tin_user(du_lieu, user_id)

    ma_phien_hien_tai, thoi_gian_reset_tiep = lay_phien_diem_danh(gio_vn)
    phien_da_diem_danh = thong_tin_user.get("phien_diem_danh_cuoi")

    if phien_da_diem_danh == ma_phien_hien_tai:
        con_lai = thoi_gian_reset_tiep - gio_vn
        gio = con_lai.seconds // 3600
        phut = (con_lai.seconds % 3600) // 60
        await interaction.response.send_message(
            f"⏳ Bạn đã điểm danh phiên hôm nay rồi! Phiên mới bắt đầu lúc **7:00 sáng**, quay lại sau **{gio} giờ {phut} phút** nữa nhé.",
            ephemeral=True,
        )
        return

    # Tính streak (số ngày điểm danh liên tiếp)
    streak_cu = thong_tin_user.get("streak_diem_danh", 0)
    if phien_da_diem_danh:
        try:
            ngay_truoc = datetime.strptime(phien_da_diem_danh, "%Y-%m-%d")
            ngay_du_kien_tiep_theo = (ngay_truoc + timedelta(days=1)).strftime("%Y-%m-%d")
            if ngay_du_kien_tiep_theo == ma_phien_hien_tai:
                streak_moi = streak_cu + 1  # điểm danh đúng ngày kế tiếp, streak tăng
            else:
                streak_moi = 1  # bỏ lỡ ít nhất 1 ngày, reset streak
        except Exception:
            streak_moi = 1
    else:
        streak_moi = 1  # lần đầu điểm danh

    xu_nhan_duoc = tinh_xu_theo_streak(streak_moi)
    thong_tin_user["xu"] = thong_tin_user.get("xu", 0) + xu_nhan_duoc
    thong_tin_user["phien_diem_danh_cuoi"] = ma_phien_hien_tai
    thong_tin_user["streak_diem_danh"] = streak_moi
    du_lieu[user_id] = thong_tin_user
    ghi_json(ECONOMY_FILE, du_lieu)

    embed = discord.Embed(
        title="✅ Điểm danh thành công!",
        description=(
            f"Bạn nhận được **{xu_nhan_duoc:,} Bxu 🪙** 🎉\n"
            f"🔥 Streak hiện tại: **{streak_moi} ngày** liên tiếp\n"
            f"Tổng số Bxu 🪙 hiện có: **{thong_tin_user['xu']:,}** Bxu 🪙"
        ),
        color=discord.Color.green(),
    )
    await interaction.response.send_message(embed=embed)


# ============ LỆNH /muasp (mua sản phẩm) ============
@bot.tree.command(name="muasp", description="Mua sản phẩm trong cửa hàng theo ID")
@app_commands.describe(id="ID sản phẩm (xem trong /cuahang)", soluong="Số lượng muốn mua")
async def muasp(interaction: discord.Interaction, id: str, soluong: int):
    if soluong <= 0:
        await interaction.response.send_message("Số lượng phải lớn hơn 0 nhé.", ephemeral=True)
        return

    san_pham = tim_san_pham_theo_id(id)
    if not san_pham:
        await interaction.response.send_message(
            f"Không tìm thấy sản phẩm với ID `{id}`. Dùng /cuahang để xem danh sách.",
            ephemeral=True,
        )
        return

    gia_don_vi = san_pham.get("gia", 0)
    tong_tien = gia_don_vi * soluong

    # Kiểm tra tồn kho (nếu sản phẩm có quản lý số lượng trong tonkho.json)
    ton_kho = doc_json(TONKHO_FILE, {})
    so_luong_con = ton_kho.get(str(id))
    if so_luong_con is not None and so_luong_con < soluong:
        await interaction.response.send_message(
            f"⚠️ Sản phẩm này chỉ còn **{so_luong_con}**, không đủ số lượng bạn yêu cầu.",
            ephemeral=True,
        )
        return

    du_lieu = doc_json(ECONOMY_FILE, {})
    user_id = str(interaction.user.id)
    thong_tin_user = lay_thong_tin_user(du_lieu, user_id)
    xu_hien_co = thong_tin_user.get("xu", 0)

    la_tai_khoan_test = la_admin(interaction.user.id)

    if not la_tai_khoan_test and xu_hien_co < tong_tien:
        await interaction.response.send_message(
            f"Bạn không đủ Bxu 🪙! Cần **{tong_tien:,} Bxu 🪙**, bạn hiện có **{xu_hien_co:,} Bxu 🪙**.",
            ephemeral=True,
        )
        return

    # Trừ xu và lưu lại (bỏ qua nếu là tài khoản test)
    if not la_tai_khoan_test:
        thong_tin_user["xu"] = xu_hien_co - tong_tien
        du_lieu[user_id] = thong_tin_user
        ghi_json(ECONOMY_FILE, du_lieu)

    # Trừ tồn kho nếu sản phẩm có quản lý số lượng
    if so_luong_con is not None:
        ton_kho[str(id)] = so_luong_con - soluong
        ghi_json(TONKHO_FILE, ton_kho)

    # Lưu lại đơn hàng vào lịch sử
    bay_gio = datetime.now(timezone.utc)
    du_lieu_don = doc_json(ORDERS_FILE, {"orders": []})
    danh_sach_don = du_lieu_don.get("orders", [])
    ma_don_moi = lay_id_don_moi(danh_sach_don)

    don_hang = {
        "id": ma_don_moi,
        "nguoi_mua_id": interaction.user.id,
        "ten_nguoi_mua": interaction.user.name,
        "san_pham_id": id,
        "ten_san_pham": san_pham.get("ten"),
        "so_luong": soluong,
        "tong_tien": tong_tien,
        "thoi_gian": bay_gio.isoformat(),
        "trang_thai": "cho_xu_ly",
    }
    danh_sach_don.append(don_hang)
    du_lieu_don["orders"] = danh_sach_don
    ghi_json(ORDERS_FILE, du_lieu_don)

    embed = discord.Embed(
        title="✅ Mua hàng thành công!",
        description=(
            f"Bạn đã mua **{soluong} x {san_pham.get('ten')}**\n"
            f"Tổng cộng: **{tong_tien:,} Bxu 🪙**\n"
            f"Số Bxu 🪙 còn lại: **{thong_tin_user['xu']:,} Bxu 🪙**\n\n"
            f"Admin sẽ xử lý đơn của bạn sớm nhé! (Mã đơn: {ma_don_moi})"
        ),
        color=discord.Color.blue(),
    )
    await interaction.response.send_message(embed=embed)

    # Gửi thông báo cho admin qua DM, kèm 2 nút bấm
    if ADMIN_ID:
        try:
            admin_user = await bot.fetch_user(int(ADMIN_ID))
            thong_bao = discord.Embed(
                title="🔔 Có đơn hàng mới!",
                description=(
                    f"**Người mua:** {interaction.user.mention} ({interaction.user.name})\n"
                    f"**Sản phẩm:** {san_pham.get('ten')} (ID: {id})\n"
                    f"**Số lượng:** {soluong}\n"
                    f"**Tổng tiền:** {tong_tien:,} Bxu 🪙\n"
                    f"**Server:** {interaction.guild.name if interaction.guild else 'DM'}"
                ),
                color=discord.Color.orange(),
            )
            thong_bao.set_footer(text=f"ID Đơn Hàng: {ma_don_moi}")
            await admin_user.send(embed=thong_bao, view=OrderActionView())
        except Exception as e:
            print(f"Không gửi được thông báo cho admin: {e}")


# ============ LỆNH /checkxu (xem số xu hiện có) ============
@bot.tree.command(name="checkxu", description="Xem số Bxu 🪙 bạn đang có")
async def checkxu(interaction: discord.Interaction):
    du_lieu = doc_json(ECONOMY_FILE, {})
    user_id = str(interaction.user.id)
    thong_tin_user = lay_thong_tin_user(du_lieu, user_id)

    if la_admin(interaction.user.id):
        mo_ta = "Bạn hiện có **♾️ Bxu 🪙** (chế độ test - không giới hạn)"
    else:
        mo_ta = f"Bạn hiện có **{thong_tin_user.get('xu', 0):,} Bxu 🪙**"

    embed = discord.Embed(
        title="💰 Số Dư Của Bạn",
        description=mo_ta,
        color=discord.Color.teal(),
    )
    
    await interaction.response.send_message(embed=embed, ephemeral=True)


# ============ LỆNH /lsmua (lịch sử mua hàng) ============
@bot.tree.command(name="lsmua", description="Xem lịch sử các đơn hàng bạn đã mua")
async def lsmua(interaction: discord.Interaction):
    du_lieu_don = doc_json(ORDERS_FILE, {"orders": []})
    danh_sach_don = du_lieu_don.get("orders", [])

    don_cua_toi = [d for d in danh_sach_don if str(d.get("nguoi_mua_id")) == str(interaction.user.id)]

    if not don_cua_toi:
        await interaction.response.send_message("Bạn chưa có đơn hàng nào.", ephemeral=True)
        return

    # Lấy 10 đơn gần nhất, mới nhất lên trên
    don_cua_toi = list(reversed(don_cua_toi))[:10]

    embed = discord.Embed(
        title="📜 Lịch Sử Mua Hàng Của Bạn",
        description=f"{len(don_cua_toi)} đơn gần nhất:",
        color=discord.Color.blurple(),
    )

    for don in don_cua_toi:
        trang_thai = NHAN_TRANG_THAI.get(don.get("trang_thai"), "?")
        try:
            thoi_gian = datetime.fromisoformat(don.get("thoi_gian"))
            thoi_gian_vn = (thoi_gian + timedelta(hours=7)).strftime("%H:%M %d/%m/%Y")
        except Exception:
            thoi_gian_vn = "?"

        embed.add_field(
            name=f"Mã đơn #{don.get('id')} — {don.get('ten_san_pham')}",
            value=(
                f"Số lượng: {don.get('so_luong')} | Tổng: {don.get('tong_tien'):,} Bxu 🪙\n"
                f"Trạng thái: {trang_thai}\n"
                f"Thời gian: {thoi_gian_vn}"
            ),
            inline=False,
        )

    await interaction.response.send_message(embed=embed, ephemeral=True)


# ============ LỆNH /ttcn (thông tin cá nhân) ============
@bot.tree.command(name="ttcn", description="Xem thông tin cá nhân của bạn")
async def ttcn(interaction: discord.Interaction):
    user_id = str(interaction.user.id)
    du_lieu_economy = doc_json(ECONOMY_FILE, {})
    thong_tin_user = lay_thong_tin_user(du_lieu_economy, user_id)
    xu = thong_tin_user.get("xu", 0)
    streak = thong_tin_user.get("streak_diem_danh", 0)

    # Tính hạng trong bảng xếp hạng
    danh_sach_xep_hang = sorted(
        [(uid, tt.get("xu", 0)) for uid, tt in du_lieu_economy.items() if not la_admin(uid)],
        key=lambda x: x[1],
        reverse=True,
    )
    hang = None
    for i, (uid, _) in enumerate(danh_sach_xep_hang):
        if uid == user_id:
            hang = i + 1
            break

    # Đếm tổng số đơn đã mua
    du_lieu_don = doc_json(ORDERS_FILE, {"orders": []})
    so_don = sum(1 for d in du_lieu_don.get("orders", []) if str(d.get("nguoi_mua_id")) == user_id)

    embed = discord.Embed(
        title=f"🪪 Thông Tin Cá Nhân - {interaction.user.display_name}",
        color=discord.Color.blurple(),
    )
    embed.set_thumbnail(url=interaction.user.display_avatar.url)
    embed.add_field(name="💰 Số Bxu 🪙", value=f"{xu:,} Bxu 🪙", inline=True)
    embed.add_field(name="🔥 Streak điểm danh", value=f"{streak} ngày", inline=True)
    embed.add_field(name="🏆 Hạng BXH", value=(f"#{hang}" if hang else "Chưa có hạng"), inline=True)
    embed.add_field(name="🛍️ Tổng đơn đã mua", value=f"{so_don} đơn", inline=True)
    await interaction.response.send_message(embed=embed, ephemeral=True)


# ============ FORM VIẾT GHI CHÚ CÁ NHÂN ============
class NoteModal(discord.ui.Modal, title="Viết Ghi Chú Của Bạn"):
    noidung = discord.ui.TextInput(
        label="Nội dung ghi chú",
        style=discord.TextStyle.paragraph,
        placeholder="Nhập nội dung bạn muốn ghi chú lại...",
        max_length=4000,
        required=True,
    )
    matkhau = discord.ui.TextInput(
        label="Mật khẩu (không bắt buộc, để chia sẻ)",
        placeholder="Để trống nếu chỉ muốn riêng mình bạn xem",
        required=False,
    )

    async def on_submit(self, interaction: discord.Interaction):
        user_id = str(interaction.user.id)
        du_lieu = doc_json(NOTES_FILE, {})
        danh_sach_note = du_lieu.get(user_id, [])

        ma_note_moi = lay_id_note_moi(du_lieu)
        mat_khau_gia_tri = self.matkhau.value or None
        danh_sach_note.append(
            {
                "id": ma_note_moi,
                "noi_dung": self.noidung.value,
                "matkhau": mat_khau_gia_tri,
                "thoi_gian": datetime.now(timezone.utc).isoformat(),
            }
        )
        du_lieu[user_id] = danh_sach_note
        ghi_json(NOTES_FILE, du_lieu)

        embed = discord.Embed(
            title="📝 Đã Lưu Ghi Chú!",
            description=f"\"{self.noidung.value}\"",
            color=discord.Color.teal(),
        )
        embed.add_field(name="🆔 Mã ghi chú", value=f"`{ma_note_moi}`", inline=True)
        embed.add_field(name="📦 Tổng ghi chú", value=f"{len(danh_sach_note)}", inline=True)
        if mat_khau_gia_tri:
            embed.add_field(
                name="🔓 Chia sẻ được",
                value="Người khác có thể xem note này qua /xemnote nếu biết mã + mật khẩu đúng.",
                inline=False,
            )
        embed.set_footer(
            text="⚠️ Mọi sự mất mát, chúng tôi không chịu trách nhiệm. Hãy cẩn thận và đừng lưu trữ tài khoản cá nhân."
        )
        await interaction.response.send_message(embed=embed, ephemeral=True)


# ============ LỆNH /note (ghi chú cá nhân) ============
@bot.tree.command(name="note", description="Ghi chú lại điều gì đó cho riêng bạn")
async def note(interaction: discord.Interaction):
    await interaction.response.send_modal(NoteModal())


# ============ LỆNH /luutrunote (xem lại ghi chú đã lưu) ============
@bot.tree.command(name="luutrunote", description="Xem lại các ghi chú bạn đã lưu")
async def luutrunote(interaction: discord.Interaction):
    user_id = str(interaction.user.id)
    du_lieu = doc_json(NOTES_FILE, {})
    danh_sach_note = du_lieu.get(user_id, [])

    if not danh_sach_note:
        await interaction.response.send_message("Bạn chưa có ghi chú nào cả.", ephemeral=True)
        return

    danh_sach_note = list(reversed(danh_sach_note))[:10]

    embed = discord.Embed(
        title="📒 Ghi Chú Của Bạn",
        description=f"{len(danh_sach_note)} ghi chú gần nhất",
        color=discord.Color.blurple(),
    )
    for note_item in danh_sach_note:
        try:
            thoi_gian = datetime.fromisoformat(note_item.get("thoi_gian"))
            thoi_gian_vn = (thoi_gian + timedelta(hours=7)).strftime("%H:%M %d/%m/%Y")
        except Exception:
            thoi_gian_vn = "?"
        trang_thai = "Có thể chia sẻ" if note_item.get("matkhau") else "Riêng tư"
        embed.add_field(
            name=f"`{note_item.get('id', '?')}`  ·  {thoi_gian_vn}  ·  {trang_thai}",
            value=f"> {note_item.get('noi_dung', '')}",
            inline=False,
        )
    await interaction.response.send_message(embed=embed, ephemeral=True)


# ============ FORM XEM GHI CHÚ NGƯỜI KHÁC ============
class XemNoteModal(discord.ui.Modal, title="Xem Ghi Chú"):
    manote = discord.ui.TextInput(label="Mã ghi chú (6 ký tự)", placeholder="Ví dụ: ABC123", required=True)
    matkhau = discord.ui.TextInput(label="Mật khẩu", placeholder="Nhập mật khẩu của ghi chú đó", required=True)

    async def on_submit(self, interaction: discord.Interaction):
        ma_chuan_hoa = self.manote.value.strip().upper()
        du_lieu = doc_json(NOTES_FILE, {})

        note_tim_thay = None
        chu_note_id = None
        for uid, danh_sach in du_lieu.items():
            for note_item in danh_sach:
                if str(note_item.get("id", "")).upper() == ma_chuan_hoa:
                    note_tim_thay = note_item
                    chu_note_id = uid
                    break
            if note_tim_thay:
                break

        if not note_tim_thay:
            await interaction.response.send_message(f"Không tìm thấy ghi chú với mã `{ma_chuan_hoa}`.", ephemeral=True)
            return

        mat_khau_that = note_tim_thay.get("matkhau")
        if not mat_khau_that:
            await interaction.response.send_message(
                "🔒 Ghi chú này không được chia sẻ (chủ note chưa đặt mật khẩu).", ephemeral=True
            )
            return

        if self.matkhau.value != mat_khau_that:
            await interaction.response.send_message("❌ Sai mật khẩu.", ephemeral=True)
            return

        try:
            thoi_gian = datetime.fromisoformat(note_tim_thay.get("thoi_gian"))
            thoi_gian_vn = (thoi_gian + timedelta(hours=7)).strftime("%H:%M %d/%m/%Y")
        except Exception:
            thoi_gian_vn = "?"

        embed = discord.Embed(
            title=f"🔓 Ghi Chú `{ma_chuan_hoa}`",
            description=f"> {note_tim_thay.get('noi_dung', '')}",
            color=discord.Color.blurple(),
        )
        embed.add_field(name="Người viết", value=f"<@{chu_note_id}>", inline=True)
        embed.add_field(name="Thời gian", value=thoi_gian_vn, inline=True)
        await interaction.response.send_message(embed=embed, ephemeral=True)


# ============ LỆNH /xemnote (xem note người khác nếu biết mật khẩu) ============
@bot.tree.command(name="xemnote", description="Xem ghi chú của người khác nếu biết mã và mật khẩu")
async def xemnote(interaction: discord.Interaction):
    await interaction.response.send_modal(XemNoteModal())


# ============ LỆNH /xoatatca (chỉ admin - xóa dữ liệu theo ID + chọn rõ loại) ============
@bot.tree.command(name="xoatatca", description="[CHỈ ADMIN] Xóa dữ liệu theo ID, chọn rõ loại để tránh xóa nhầm")
@app_commands.describe(id="ID cần xóa (mã đơn hàng, mã ghi chú, mã giao dịch...)", loai="Chọn loại dữ liệu cần xóa")
@app_commands.choices(loai=[
    app_commands.Choice(name="🛍️ Đơn hàng mua sản phẩm", value="don_hang"),
    app_commands.Choice(name="📝 Ghi chú cá nhân", value="ghi_chu"),
    app_commands.Choice(name="💳 Yêu cầu nạp thẻ", value="nap_the"),
    app_commands.Choice(name="🏦 Yêu cầu nạp bank", value="nap_bank"),
    app_commands.Choice(name="🔄 Giao dịch chuyển Bxu", value="giao_dich_bxu"),
    app_commands.Choice(name="🎟️ Mã code đổi xu", value="ma_code"),
])
async def xoatatca(interaction: discord.Interaction, id: str, loai: app_commands.Choice[str]):
    if not la_admin(interaction.user.id):
        await interaction.response.send_message("❌ Bạn không có quyền dùng lệnh này.", ephemeral=True)
        return

    id_goc = id.strip()
    id_chuan_hoa = id_goc.upper()
    da_xoa = False
    nhan_loai = loai.name

    # ---- Đơn hàng mua sản phẩm ----
    if loai.value == "don_hang":
        du_lieu = doc_json(ORDERS_FILE, {"orders": []})
        danh_sach = du_lieu.get("orders", [])
        con_lai = [d for d in danh_sach if str(d.get("id")) != id_goc]
        if len(con_lai) != len(danh_sach):
            ghi_json(ORDERS_FILE, {"orders": con_lai})
            da_xoa = True

    # ---- Ghi chú cá nhân ----
    elif loai.value == "ghi_chu":
        du_lieu = doc_json(NOTES_FILE, {})
        for user_id, danh_sach_note in du_lieu.items():
            con_lai = [n for n in danh_sach_note if str(n.get("id", "")).upper() != id_chuan_hoa]
            if len(con_lai) != len(danh_sach_note):
                du_lieu[user_id] = con_lai
                da_xoa = True
        if da_xoa:
            ghi_json(NOTES_FILE, du_lieu)

    # ---- Yêu cầu nạp thẻ ----
    elif loai.value == "nap_the":
        du_lieu = doc_json(NAPTHE_FILE, {"requests": []})
        danh_sach = du_lieu.get("requests", [])
        con_lai = [yc for yc in danh_sach if str(yc.get("id")) != id_goc]
        if len(con_lai) != len(danh_sach):
            ghi_json(NAPTHE_FILE, {"requests": con_lai})
            da_xoa = True

    # ---- Yêu cầu nạp bank ----
    elif loai.value == "nap_bank":
        du_lieu = doc_json(NAPBANK_FILE, {"requests": []})
        danh_sach = du_lieu.get("requests", [])
        con_lai = [yc for yc in danh_sach if str(yc.get("id")) != id_goc]
        if len(con_lai) != len(danh_sach):
            ghi_json(NAPBANK_FILE, {"requests": con_lai})
            da_xoa = True

    # ---- Giao dịch chuyển Bxu ----
    elif loai.value == "giao_dich_bxu":
        du_lieu = doc_json(CHUYENBXU_FILE, {"giao_dich": []})
        danh_sach = du_lieu.get("giao_dich", [])
        con_lai = [gd for gd in danh_sach if str(gd.get("id")) != id_goc]
        if len(con_lai) != len(danh_sach):
            ghi_json(CHUYENBXU_FILE, {"giao_dich": con_lai})
            da_xoa = True

    # ---- Mã code đổi xu ----
    elif loai.value == "ma_code":
        du_lieu = doc_json(CODES_FILE, {})
        if id_chuan_hoa in du_lieu:
            del du_lieu[id_chuan_hoa]
            ghi_json(CODES_FILE, du_lieu)
            da_xoa = True

    # ---- Trả kết quả ----
    if not da_xoa:
        await interaction.response.send_message(
            f"Không tìm thấy **{nhan_loai}** nào có ID `{id_goc}`.", ephemeral=True
        )
        return

    embed = discord.Embed(
        title="🗑️ Đã Xóa Thành Công!",
        description=f"Đã xóa **{nhan_loai}** với ID `{id_goc}`.",
        color=discord.Color.red(),
    )
    await interaction.response.send_message(embed=embed, ephemeral=True)


# ============ THAY THẾ 1: lệnh /taocode ============
@bot.tree.command(name="taocode", description="[CHỈ ADMIN] Tạo mã code để member nhập lấy Bxu 🪙")
@app_commands.describe(
    ma="Mã code (tự đặt, vd: TET2026)",
    hethansau="Thời hạn dùng, vd: 30m, 1h, 2h, 1day",
    soluongxu="Số Bxu 🪙 nhận được khi nhập đúng mã",
    gioihansonguoi="Giới hạn số người được nhập (để trống = không giới hạn)",
)
async def taocode(interaction: discord.Interaction, ma: str, hethansau: str, soluongxu: int, gioihansonguoi: int = None):
    if not la_admin(interaction.user.id):
        await interaction.response.send_message("❌ Bạn không có quyền dùng lệnh này.", ephemeral=True)
        return

    if soluongxu <= 0:
        await interaction.response.send_message("Số Bxu 🪙 phải lớn hơn 0 nhé.", ephemeral=True)
        return

    if gioihansonguoi is not None and gioihansonguoi <= 0:
        await interaction.response.send_message("Giới hạn số người phải lớn hơn 0 nhé.", ephemeral=True)
        return

    thoi_luong = parse_thoigian(hethansau)
    if thoi_luong is None:
        await interaction.response.send_message("Định dạng thời gian không đúng. Ví dụ hợp lệ: `30m`, `1h`, `2h`, `1day`.", ephemeral=True)
        return

    ma_chuan_hoa = ma.strip().upper()
    du_lieu = doc_json(CODES_FILE, {})

    if ma_chuan_hoa in du_lieu:
        await interaction.response.send_message(f"⚠️ Mã `{ma_chuan_hoa}` đã tồn tại rồi, dùng mã khác nhé.", ephemeral=True)
        return

    het_han = datetime.now(timezone.utc) + thoi_luong
    du_lieu[ma_chuan_hoa] = {
        "soluongxu": soluongxu,
        "het_han": het_han.isoformat(),
        "da_dung": [],
        "gioi_han_so_nguoi": gioihansonguoi,
    }
    ghi_json(CODES_FILE, du_lieu)

    het_han_vn = (het_han + timedelta(hours=7)).strftime("%H:%M:%S ngày %d/%m/%Y")
    dong_gioihan = f"👥 Giới hạn: **{gioihansonguoi} người**\n" if gioihansonguoi else ""
    embed = discord.Embed(
        title="✅ Đã tạo mã code mới!",
        description=(
            f"🎟️ Mã: `{ma_chuan_hoa}`\n"
            f"🎁 Phần thưởng: **{soluongxu:,} Bxu 🪙**\n"
            f"{dong_gioihan}"
            f"⏰ Hết hạn lúc: **{het_han_vn}** (giờ VN)\n\n"
            f"Member dùng `/nhapcode ma:{ma_chuan_hoa}` để nhận."
        ),
        color=discord.Color.green(),
    )
    await interaction.response.send_message(embed=embed, ephemeral=True)


# ============ THAY THẾ 2: lệnh /nhapcode ============
@bot.tree.command(name="nhapcode", description="Nhập mã code để nhận Bxu 🪙")
@app_commands.describe(ma="Mã code bạn muốn nhập")
async def nhapcode(interaction: discord.Interaction, ma: str):
    if la_bi_cam(interaction.user.id):
        await interaction.response.send_message("🚫 Bạn đang bị cấm dùng lệnh kiếm Bxu 🪙.", ephemeral=True)
        return

    ma_chuan_hoa = ma.strip().upper()
    du_lieu = doc_json(CODES_FILE, {})
    thong_tin_code = du_lieu.get(ma_chuan_hoa)

    if not thong_tin_code:
        await interaction.response.send_message(f"❌ Mã `{ma_chuan_hoa}` không tồn tại.", ephemeral=True)
        return

    het_han = datetime.fromisoformat(thong_tin_code["het_han"])
    if datetime.now(timezone.utc) > het_han:
        await interaction.response.send_message(f"⏳ Mã `{ma_chuan_hoa}` đã hết hạn rồi.", ephemeral=True)
        return

    da_dung = thong_tin_code.get("da_dung", [])
    gioi_han = thong_tin_code.get("gioi_han_so_nguoi")
    if gioi_han is not None and len(da_dung) >= gioi_han:
        await interaction.response.send_message(f"⚠️ Mã `{ma_chuan_hoa}` đã đủ số người nhập tối đa ({gioi_han} người).", ephemeral=True)
        return

    user_id = interaction.user.id
    if user_id in da_dung:
        await interaction.response.send_message(f"⚠️ Bạn đã nhập mã `{ma_chuan_hoa}` rồi.", ephemeral=True)
        return

    soluongxu = thong_tin_code.get("soluongxu", 0)
    thong_tin_code.setdefault("da_dung", []).append(user_id)
    du_lieu[ma_chuan_hoa] = thong_tin_code
    ghi_json(CODES_FILE, du_lieu)

    du_lieu_economy = doc_json(ECONOMY_FILE, {})
    user_id_str = str(user_id)
    thong_tin_user = lay_thong_tin_user(du_lieu_economy, user_id_str)
    thong_tin_user["xu"] = thong_tin_user.get("xu", 0) + soluongxu
    du_lieu_economy[user_id_str] = thong_tin_user
    ghi_json(ECONOMY_FILE, du_lieu_economy)

    embed = discord.Embed(
        title="🎉 Nhập mã thành công!",
        description=f"Bạn nhận được **{soluongxu:,} Bxu 🪙** 🎁\nTổng số Bxu 🪙 hiện có: **{thong_tin_user['xu']:,} Bxu 🪙**",
        color=discord.Color.gold(),
    )
    await interaction.response.send_message(embed=embed, ephemeral=True)
        


# ============ NÚT BẤM XỬ LÝ YÊU CẦU NẠP THẺ (Done / Từ chối) ============
# ============ CẤU HÌNH ROLE THEO MỨC NẠP ============
GUILD_ID = 1529754709622263879  # ⚠️ ID server Discord của bạn (chuột phải vào tên server -> Copy Server ID)
ROLE_ID_MUC_1 = 1540005376274202635  # ⚠️ Role cho mức nạp 50,000 - 249,000
ROLE_ID_MUC_2 = 1540004815768256542  # ⚠️ Role cho mức nạp từ 250,000 trở lên


async def gan_role_theo_muc_nap(user_id: str, so_tien_vnd: int):
    """Tự động gán role tương ứng dựa trên số tiền nạp (card hoặc bank).
    Không xoá role cũ nếu user đã có role mức thấp hơn trước đó -> tự cộng dồn.
    Gọi hàm này ngay sau khi cộng Bxu thành công cho user."""
    if not GUILD_ID or not (ROLE_ID_MUC_1 or ROLE_ID_MUC_2):
        return  # chưa cấu hình -> bỏ qua, không lỗi

    guild = bot.get_guild(GUILD_ID) or await bot.fetch_guild(GUILD_ID)
    if not guild:
        print("Không tìm thấy guild để gán role.")
        return

    try:
        member = guild.get_member(int(user_id)) or await guild.fetch_member(int(user_id))
    except discord.NotFound:
        print(f"Không tìm thấy member {user_id} trong guild để gán role.")
        return

    role_can_gan = None
    if 50000 <= so_tien_vnd <= 249000:
        role_can_gan = guild.get_role(ROLE_ID_MUC_1)
    elif so_tien_vnd >= 250000:
        role_can_gan = guild.get_role(ROLE_ID_MUC_2)

    if role_can_gan and role_can_gan not in member.roles:
        try:
            await member.add_roles(role_can_gan, reason=f"Nạp {so_tien_vnd:,}đ")
        except Exception as e:
            print(f"Không gán được role cho {user_id}: {e}")
class NapTheActionView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)  # không hết hạn, hoạt động kể cả sau khi bot restart

    @discord.ui.button(label="Hoàn thành", style=discord.ButtonStyle.success, custom_id="napthe_done", emoji="✅")
    async def nut_hoan_thanh(self, interaction: discord.Interaction, button: discord.ui.Button):
        await xu_ly_nut_napthe(interaction, "hoan_thanh")

    @discord.ui.button(label="Từ chối", style=discord.ButtonStyle.danger, custom_id="napthe_reject", emoji="❌")
    async def nut_tu_choi(self, interaction: discord.Interaction, button: discord.ui.Button):
        await xu_ly_nut_napthe(interaction, "tu_choi")


async def xu_ly_nut_napthe(interaction: discord.Interaction, hanh_dong: str):
    if not la_admin(interaction.user.id):
        await interaction.response.send_message("❌ Bạn không có quyền bấm nút này.", ephemeral=True)
        return

    if not interaction.message.embeds:
        await interaction.response.send_message("Không đọc được thông tin yêu cầu.", ephemeral=True)
        return

    embed_cu = interaction.message.embeds[0]
    footer_text = embed_cu.footer.text or ""
    try:
        ma_yeu_cau = footer_text.split(":")[-1].strip()
    except Exception:
        await interaction.response.send_message("Không đọc được mã yêu cầu.", ephemeral=True)
        return

    du_lieu = doc_json(NAPTHE_FILE, {"requests": []})
    danh_sach = du_lieu.get("requests", [])
    yeu_cau = None
    for yc in danh_sach:
        if str(yc.get("id")) == str(ma_yeu_cau):
            yeu_cau = yc
            break

    if not yeu_cau:
        await interaction.response.send_message("Không tìm thấy yêu cầu này.", ephemeral=True)
        return

    if yeu_cau.get("trang_thai") != "cho_xu_ly":
        await interaction.response.send_message("Yêu cầu này đã được xử lý rồi.", ephemeral=True)
        return

    nguoi_gui_id = str(yeu_cau.get("user_id"))
    thoi_gian_xu_ly = (datetime.now(timezone.utc) + timedelta(hours=7)).strftime("%H:%M:%S ngày %d/%m/%Y")

    if hanh_dong == "hoan_thanh":
        menh_gia = yeu_cau.get("menh_gia", 0)
        xu_nhan = TY_GIA_CARD.get(menh_gia, menh_gia)  # tra bảng tỷ giá, mệnh giá lạ thì fallback 1:1

        du_lieu_economy = doc_json(ECONOMY_FILE, {})
        thong_tin_user = lay_thong_tin_user(du_lieu_economy, nguoi_gui_id)
        thong_tin_user["xu"] = thong_tin_user.get("xu", 0) + xu_nhan
        du_lieu_economy[nguoi_gui_id] = thong_tin_user
        ghi_json(ECONOMY_FILE, du_lieu_economy)

        await gan_role_theo_muc_nap(nguoi_gui_id, menh_gia)
        yeu_cau["trang_thai"] = "hoan_thanh"
        mau = discord.Color.green()
        dong_them = f"✅ **Đã cộng {xu_nhan:,} Bxu 🪙** cho người gửi."
    else:
        yeu_cau["trang_thai"] = "tu_choi"
        mau = discord.Color.red()
        dong_them = "❌ **Đã từ chối** (thẻ sai/đã dùng/không hợp lệ)."

    ghi_json(NAPTHE_FILE, du_lieu)

    embed_moi = embed_cu.copy()
    embed_moi.color = mau
    embed_moi.add_field(name="Kết quả", value=dong_them, inline=False)

    view_moi = NapTheActionView()
    for item in view_moi.children:
        item.disabled = True

    await interaction.response.edit_message(embed=embed_moi, view=view_moi)

    if hanh_dong == "hoan_thanh" and LOG_NAPXU_CHANNEL_ID:
        try:
            kenh_log = bot.get_channel(int(LOG_NAPXU_CHANNEL_ID)) or await bot.fetch_channel(int(LOG_NAPXU_CHANNEL_ID))
            embed_log = discord.Embed(
                title="💳 NẠP THẺ THÀNH CÔNG",
                color=discord.Color.green(),
            )
            embed_log.add_field(name="🆔 Mã giao dịch", value=f"`{yeu_cau.get('id')}`", inline=False)
            embed_log.add_field(name="👤 Người dùng", value=f"<@{nguoi_gui_id}>", inline=False)
            embed_log.add_field(name="💰 Mệnh giá thẻ", value=f"{yeu_cau.get('menh_gia', 0):,}đ", inline=True)
            embed_log.add_field(name="🎁 Bxu Nhận Được", value=f"{xu_nhan:,} Bxu 🪙", inline=True)
            embed_log.add_field(
                name="💳 Chi tiết thẻ",
                value=f"Nạp thẻ {yeu_cau.get('loai_the')} mệnh giá {yeu_cau.get('menh_gia', 0):,}đ",
                inline=False,
            )
            embed_log.set_footer(text=thoi_gian_xu_ly)
            await kenh_log.send(content=f"<@{nguoi_gui_id}>", embed=embed_log)
        except Exception as e:
            print(f"Không gửi được log nạp thẻ: {e}")

    try:
        nguoi_gui = await bot.fetch_user(int(nguoi_gui_id))
        if hanh_dong == "hoan_thanh":
            await nguoi_gui.send(
                f"✅ Yêu cầu nạp thẻ `{yeu_cau.get('id')}` đã hoàn thành! Bạn nhận được **{xu_nhan:,} Bxu 🪙**.\n"
                f"Thời gian xử lý: {thoi_gian_xu_ly} (giờ VN)"
            )
        else:
            await nguoi_gui.send(
                f"❌ Yêu cầu nạp thẻ `{yeu_cau.get('id')}` đã bị từ chối (thẻ sai/đã dùng/không hợp lệ).\n"
                f"Thời gian xử lý: {thoi_gian_xu_ly} (giờ VN)"
            )
    except Exception as e:
        print(f"Không gửi được DM cho người gửi yêu cầu nạp thẻ: {e}")


# ============ FORM NẠP THẺ CÀO ============
class NapTheModal(discord.ui.Modal):
    ma_the = discord.ui.TextInput(label="Mã thẻ", placeholder="Nhập mã thẻ cào", required=True)
    so_seri = discord.ui.TextInput(label="Số seri", placeholder="Nhập số seri thẻ", required=True)

    def __init__(self, loai_the: str, menh_gia: int):
        super().__init__(title=f"{loai_the} - {menh_gia:,}đ")
        self.loai_the = loai_the
        self.menh_gia = menh_gia

    async def on_submit(self, interaction: discord.Interaction):
        du_lieu = doc_json(NAPTHE_FILE, {"requests": []})
        danh_sach = du_lieu.get("requests", [])
        ma_yeu_cau = lay_id_don_moi(danh_sach)

        yeu_cau = {
            "id": ma_yeu_cau,
            "user_id": interaction.user.id,
            "ten_user": interaction.user.name,
            "loai_the": self.loai_the,
            "menh_gia": self.menh_gia,
            "ma_the": self.ma_the.value,
            "so_seri": self.so_seri.value,
            "thoi_gian": datetime.now(timezone.utc).isoformat(),
            "trang_thai": "cho_xu_ly",
        }
        danh_sach.append(yeu_cau)
        du_lieu["requests"] = danh_sach
        ghi_json(NAPTHE_FILE, du_lieu)

        await interaction.response.send_message(
            f"✅ Đã gửi yêu cầu nạp thẻ **{self.loai_the} - {self.menh_gia:,}đ**.\n"
            f"Mã yêu cầu: `{ma_yeu_cau}`. Admin sẽ kiểm tra và cộng Bxu 🪙 sớm nhé!",
            ephemeral=True,
        )

        if ADMIN_ID:
            try:
                admin_user = await bot.fetch_user(int(ADMIN_ID))
                embed = discord.Embed(
                    title="💳 Có yêu cầu nạp thẻ mới!",
                    description=(
                        f"**Người gửi:** {interaction.user.mention} ({interaction.user.name})\n"
                        f"**Loại thẻ:** {self.loai_the}\n"
                        f"**Mệnh giá:** {self.menh_gia:,}đ\n"
                        f"**Mã thẻ:** `{self.ma_the.value}`\n"
                        f"**Số seri:** `{self.so_seri.value}`"
                    ),
                    color=discord.Color.blue(),
                )
                embed.set_footer(text=f"Mã Yêu Cầu: {ma_yeu_cau}")
                await admin_user.send(embed=embed, view=NapTheActionView())
            except Exception as e:
                print(f"Không gửi được thông báo nạp thẻ cho admin: {e}")


# ============ LỆNH /napxu_card (nạp thẻ cào quy đổi xu) ============
DANH_SACH_NHA_MANG = ["VIETTEL", "MOBIFONE", "ZING", "GARENA"]
DANH_SACH_MENH_GIA = [10000, 20000, 50000, 100000]
TY_GIA_CARD = {
    10000: 7000,
    20000: 15000,
    50000: 43000,
    100000: 85000,
}


@bot.tree.command(name="napxu_card", description="Nạp thẻ cào để quy đổi ra Bxu 🪙")
@app_commands.describe(loai_the="Nhà mạng thẻ cào", menh_gia="Mệnh giá thẻ (VNĐ)")
@app_commands.choices(
    loai_the=[app_commands.Choice(name=x, value=x) for x in DANH_SACH_NHA_MANG],
    menh_gia=[app_commands.Choice(name=f"{v:,}", value=v) for v in DANH_SACH_MENH_GIA],
)
async def napxu_card(
    interaction: discord.Interaction,
    loai_the: app_commands.Choice[str],
    menh_gia: app_commands.Choice[int],
):
    await interaction.response.send_modal(NapTheModal(loai_the.value, menh_gia.value))


# ============ NÚT BẤM XỬ LÝ YÊU CẦU NẠP BANK (Done / Từ chối) ============
class NapBankActionView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)

    @discord.ui.button(label="Hoàn thành", style=discord.ButtonStyle.success, custom_id="napbank_done", emoji="✅")
    async def nut_hoan_thanh(self, interaction: discord.Interaction, button: discord.ui.Button):
        await xu_ly_nut_napbank(interaction, "hoan_thanh")

    @discord.ui.button(label="Từ chối", style=discord.ButtonStyle.danger, custom_id="napbank_reject", emoji="❌")
    async def nut_tu_choi(self, interaction: discord.Interaction, button: discord.ui.Button):
        await xu_ly_nut_napbank(interaction, "tu_choi")


async def xu_ly_nut_napbank(interaction: discord.Interaction, hanh_dong: str):
    if not la_admin(interaction.user.id):
        await interaction.response.send_message("❌ Bạn không có quyền bấm nút này.", ephemeral=True)
        return

    if not interaction.message.embeds:
        await interaction.response.send_message("Không đọc được thông tin yêu cầu.", ephemeral=True)
        return

    embed_cu = interaction.message.embeds[0]
    footer_text = embed_cu.footer.text or ""
    try:
        ma_yeu_cau = footer_text.split(":")[-1].strip()
    except Exception:
        await interaction.response.send_message("Không đọc được mã yêu cầu.", ephemeral=True)
        return

    du_lieu = doc_json(NAPBANK_FILE, {"requests": []})
    danh_sach = du_lieu.get("requests", [])
    yeu_cau = None
    for yc in danh_sach:
        if str(yc.get("id")) == str(ma_yeu_cau):
            yeu_cau = yc
            break

    if not yeu_cau:
        await interaction.response.send_message("Không tìm thấy yêu cầu này.", ephemeral=True)
        return

    if yeu_cau.get("trang_thai") != "cho_xu_ly":
        await interaction.response.send_message("Yêu cầu này đã được xử lý rồi.", ephemeral=True)
        return

    nguoi_gui_id = str(yeu_cau.get("user_id"))
    thoi_gian_xu_ly = (datetime.now(timezone.utc) + timedelta(hours=7)).strftime("%H:%M:%S ngày %d/%m/%Y")
    xu_nhan = yeu_cau.get("so_tien", 0)  # tỷ giá bank 1k = 1000 xu (1:1)

    if hanh_dong == "hoan_thanh":
        du_lieu_economy = doc_json(ECONOMY_FILE, {})
        thong_tin_user = lay_thong_tin_user(du_lieu_economy, nguoi_gui_id)
        thong_tin_user["xu"] = thong_tin_user.get("xu", 0) + xu_nhan
        du_lieu_economy[nguoi_gui_id] = thong_tin_user
        ghi_json(ECONOMY_FILE, du_lieu_economy)

        await gan_role_theo_muc_nap(nguoi_gui_id, xu_nhan)
        yeu_cau["trang_thai"] = "hoan_thanh"
        mau = discord.Color.green()
        dong_them = f"✅ **Đã cộng {xu_nhan:,} Bxu 🪙** cho người gửi."
    else:
        yeu_cau["trang_thai"] = "tu_choi"
        mau = discord.Color.red()
        dong_them = "❌ **Đã từ chối** (chưa nhận được chuyển khoản/thông tin sai)."

    ghi_json(NAPBANK_FILE, du_lieu)

    embed_moi = embed_cu.copy()
    embed_moi.color = mau
    embed_moi.add_field(name="Kết quả", value=dong_them, inline=False)

    view_moi = NapBankActionView()
    for item in view_moi.children:
        item.disabled = True

    await interaction.response.edit_message(embed=embed_moi, view=view_moi)

    if hanh_dong == "hoan_thanh" and LOG_NAPXU_CHANNEL_ID:
        try:
            kenh_log = bot.get_channel(int(LOG_NAPXU_CHANNEL_ID)) or await bot.fetch_channel(int(LOG_NAPXU_CHANNEL_ID))
            embed_log = discord.Embed(
                title="🏦 NẠP BANK THÀNH CÔNG",
                color=discord.Color.green(),
            )
            embed_log.add_field(name="🆔 Mã giao dịch", value=f"`{yeu_cau.get('id')}`", inline=False)
            embed_log.add_field(name="👤 Người dùng", value=f"<@{nguoi_gui_id}>", inline=False)
            embed_log.add_field(name="💰 Số tiền chuyển", value=f"{yeu_cau.get('so_tien', 0):,}đ", inline=True)
            embed_log.add_field(name="🎁 Bxu Nhận Được", value=f"{xu_nhan:,} Bxu 🪙", inline=True)
            embed_log.set_footer(text=thoi_gian_xu_ly)
            await kenh_log.send(content=f"<@{nguoi_gui_id}>", embed=embed_log)
        except Exception as e:
            print(f"Không gửi được log nạp bank: {e}")

    try:
        nguoi_gui = await bot.fetch_user(int(nguoi_gui_id))
        if hanh_dong == "hoan_thanh":
            await nguoi_gui.send(
                f"✅ Yêu cầu nạp bank `{yeu_cau.get('id')}` đã hoàn thành! Bạn nhận được **{xu_nhan:,} Bxu 🪙**.\n"
                f"Thời gian xử lý: {thoi_gian_xu_ly} (giờ VN)"
            )
        else:
            await nguoi_gui.send(
                f"❌ Yêu cầu nạp bank `{yeu_cau.get('id')}` đã bị từ chối.\n"
                f"Thời gian xử lý: {thoi_gian_xu_ly} (giờ VN)"
            )
    except Exception as e:
        print(f"Không gửi được DM cho người gửi yêu cầu nạp bank: {e}")


# ============ FORM NẠP BANK ============
class NapBankModal(discord.ui.Modal, title="Nạp Xu Qua Chuyển Khoản Ngân Hàng"):
    sotien = discord.ui.TextInput(
        label="Số tiền muốn nạp (VNĐ)",
        placeholder="Ví dụ: 50000",
        required=True,
    )
    ghichu = discord.ui.TextInput(
        label="Nội dung chuyển khoản / Ghi chú",
        placeholder="Ví dụ: NAP XU NGUYEN VAN A",
        required=False,
    )

    async def on_submit(self, interaction: discord.Interaction):
        try:
            so_tien = int(self.sotien.value.replace(",", "").replace(".", "").replace("đ", "").strip())
        except ValueError:
            await interaction.response.send_message("Số tiền không hợp lệ, chỉ nhập số.", ephemeral=True)
            return

        if so_tien <= 0:
            await interaction.response.send_message("Số tiền phải lớn hơn 0.", ephemeral=True)
            return

        du_lieu = doc_json(NAPBANK_FILE, {"requests": []})
        danh_sach = du_lieu.get("requests", [])
        ma_yeu_cau = lay_id_don_moi(danh_sach)

        yeu_cau = {
            "id": ma_yeu_cau,
            "user_id": interaction.user.id,
            "ten_user": interaction.user.name,
            "so_tien": so_tien,
            "ghi_chu": self.ghichu.value,
            "thoi_gian": datetime.now(timezone.utc).isoformat(),
            "trang_thai": "cho_xu_ly",
        }
        danh_sach.append(yeu_cau)
        du_lieu["requests"] = danh_sach
        ghi_json(NAPBANK_FILE, du_lieu)

        await interaction.response.send_message(
            f"✅ Đã gửi yêu cầu nạp **{so_tien:,}đ** qua bank.\n"
            f"Mã yêu cầu: `{ma_yeu_cau}`. Admin sẽ kiểm tra chuyển khoản và cộng Bxu 🪙 sớm nhé!",
            ephemeral=True,
        )

        if ADMIN_ID:
            try:
                admin_user = await bot.fetch_user(int(ADMIN_ID))
                embed = discord.Embed(
                    title="🏦 Có yêu cầu nạp bank mới!",
                    description=(
                        f"**Người gửi:** {interaction.user.mention} ({interaction.user.name})\n"
                        f"**Số tiền:** {so_tien:,}đ\n"
                        f"**Ghi chú:** {self.ghichu.value or 'Không có'}"
                    ),
                    color=discord.Color.blue(),
                )
                embed.set_footer(text=f"Mã Yêu Cầu: {ma_yeu_cau}")
                await admin_user.send(embed=embed, view=NapBankActionView())
            except Exception as e:
                print(f"Không gửi được thông báo nạp bank cho admin: {e}")


# ============ LỆNH /napxu_bank (nạp xu qua chuyển khoản) ============
@bot.tree.command(name="napxu_bank", description="Nạp Bxu 🪙 qua chuyển khoản ngân hàng")
async def napxu_bank(interaction: discord.Interaction):
    await interaction.response.send_modal(NapBankModal())


# ============ LỆNH /checkbot (trạng thái bot) ============
@bot.tree.command(name="checkbot", description="Xem trạng thái hoạt động của bot")
async def checkbot(interaction: discord.Interaction):
    bay_gio = datetime.now(timezone.utc)
    gio_vn = bay_gio + timedelta(hours=7)  # đổi sang giờ Việt Nam (UTC+7)

    thoi_gian_chay = bay_gio - THOI_GIAN_BAT_DAU
    so_ngay = thoi_gian_chay.days
    so_gio = thoi_gian_chay.seconds // 3600
    so_phut = (thoi_gian_chay.seconds % 3600) // 60

    embed = discord.Embed(
        title="🟢 Trạng Thái Bot",
        color=discord.Color.green(),
    )
    embed.add_field(name="Trạng thái", value="🟢 Đang hoạt động", inline=False)
    embed.add_field(
        name="Thời gian hiện tại",
        value=gio_vn.strftime("%H:%M:%S - %d/%m/%Y") + " (giờ VN)",
        inline=False,
    )
    embed.add_field(
        name="Đã chạy liên tục",
        value=f"{so_ngay} ngày {so_gio} giờ {so_phut} phút",
        inline=False,
    )
    embed.set_footer(text=f"Bot: {bot.user.name}")
    await interaction.response.send_message(embed=embed)

# ============ LỆNH /tokennab (mọi thành viên dùng được) ============
NABTOKEN_FILE = "nabtoken.json"


def tao_token_moi() -> str:
    """Tạo token gồm 5 chữ cái thường + 5 chữ số, xáo trộn ngẫu nhiên. VD: 1bc32a4d5e"""
    chu_cai = random.choices(string.ascii_lowercase, k=5)
    chu_so = random.choices(string.digits, k=5)
    ky_tu = chu_cai + chu_so
    random.shuffle(ky_tu)
    return "".join(ky_tu)


@bot.tree.command(name="tokennab", description="Xem token của bạn, hoặc dùng 'reset' để tạo token mới")
@app_commands.describe(hanhdong="Để trống để xem token hiện tại, hoặc nhập 'reset' để tạo token mới")
@app_commands.choices(
    hanhdong=[app_commands.Choice(name="reset - Tạo token mới", value="reset")]
)
async def tokennab(interaction: discord.Interaction, hanhdong: app_commands.Choice[str] = None):
    user_id = str(interaction.user.id)
    du_lieu = doc_json(NABTOKEN_FILE, {})

    # --- Không truyền gì -> xem token hiện tại ---
    if hanhdong is None:
        thong_tin = du_lieu.get(user_id)
        if not thong_tin:
            await interaction.response.send_message(
                "Bạn chưa có token nào cả. Dùng `/tokennab hanhdong:reset` để tạo token mới nhé.",
                ephemeral=True,
            )
            return

        try:
            thoi_gian = datetime.fromisoformat(thong_tin.get("thoi_gian"))
            thoi_gian_vn = (thoi_gian + timedelta(hours=7)).strftime("%H:%M:%S ngày %d/%m/%Y")
        except Exception:
            thoi_gian_vn = "?"

        embed = discord.Embed(
            title="🔑 Token Của Bạn",
            description=f"`{thong_tin.get('token')}`",
            color=discord.Color.blurple(),
        )
        embed.add_field(name="Tạo lúc", value=thoi_gian_vn, inline=False)
        embed.set_footer(text="Dùng /tokennab hanhdong:reset nếu muốn tạo token mới")
        await interaction.response.send_message(embed=embed, ephemeral=True)
        return

    # --- hanhdong = reset -> tạo token mới ---
    token_moi = tao_token_moi()
    du_lieu[user_id] = {
        "token": token_moi,
        "thoi_gian": datetime.now(timezone.utc).isoformat(),
    }
    ghi_json(NABTOKEN_FILE, du_lieu)

    embed = discord.Embed(
        title="✅ Token Đã Được Làm Mới!",
        description=f"Token mới của bạn:\n`{token_moi}`",
        color=discord.Color.green(),
    )
    embed.set_footer(text="⚠️ Không chia sẻ token này cho người khác.")
    await interaction.response.send_message(embed=embed, ephemeral=True)

# ============ LỆNH /bxh (bảng xếp hạng) ============
@bot.tree.command(name="bxh", description="Xem bảng xếp hạng thành viên nhiều Bxu 🪙 nhất")
async def bxh(interaction: discord.Interaction):
    du_lieu = doc_json(ECONOMY_FILE, {})

    danh_sach = [
        (uid, thong_tin.get("xu", 0))
        for uid, thong_tin in du_lieu.items()
        if not la_admin(uid) and thong_tin.get("xu", 0) > 0
    ]
    danh_sach.sort(key=lambda x: x[1], reverse=True)
    top = danh_sach[:10]

    if not top:
        await interaction.response.send_message("Chưa có ai có Bxu 🪙 để xếp hạng cả.", ephemeral=True)
        return

    huy_chuong = ["🥇", "🥈", "🥉"]
    dong_noi_dung = []
    for i, (uid, xu) in enumerate(top):
        hang = huy_chuong[i] if i < 3 else f"**{i + 1}.**"
        dong_noi_dung.append(f"{hang} <@{uid}> — **{xu:,} Bxu 🪙**")

    embed = discord.Embed(
        title="🏆 Bảng Xếp Hạng Xu",
        description="\n".join(dong_noi_dung),
        color=discord.Color.gold(),
    )
    await interaction.response.send_message(embed=embed)


# ============ LỆNH /eventxu (chỉ admin - giveaway xu) ============
@bot.tree.command(name="eventxu", description="[CHỈ ADMIN] Tạo event giveaway Bxu 🪙")
@app_commands.describe(
    ketthucsau="Thời gian diễn ra event, vd: 30m, 1h, 2h, 1day",
    soluongxu="Số Bxu 🪙 thưởng cho người thắng",
)
async def eventxu(interaction: discord.Interaction, ketthucsau: str, soluongxu: int):
    if not la_admin(interaction.user.id):
        await interaction.response.send_message("❌ Bạn không có quyền dùng lệnh này.", ephemeral=True)
        return

    if soluongxu <= 0:
        await interaction.response.send_message("Số Bxu 🪙 phải lớn hơn 0 nhé.", ephemeral=True)
        return

    thoi_luong = parse_thoigian(ketthucsau)
    if thoi_luong is None:
        await interaction.response.send_message(
            "Định dạng thời gian không đúng. Ví dụ hợp lệ: `30m`, `1h`, `2h`, `1day`.",
            ephemeral=True,
        )
        return

    thoi_gian_ket_thuc = datetime.now(timezone.utc) + thoi_luong
    gio_vn = (thoi_gian_ket_thuc + timedelta(hours=7)).strftime("%H:%M:%S ngày %d/%m/%Y")

    embed = discord.Embed(
        title="🎉 Event Tặng Xu!",
        description=(
            f"Bấm nút bên dưới để tham gia!\n\n"
            f"🎁 Phần thưởng: **{soluongxu:,} Bxu 🪙** cho 1 người may mắn\n"
            f"⏰ Kết thúc lúc: **{gio_vn}** (giờ VN)"
        ),
        color=discord.Color.gold(),
    )

    view = EventXuView()
    await interaction.response.send_message(embed=embed, view=view)
    tin_nhan = await interaction.original_response()

    du_lieu_event = doc_json(EVENTS_FILE, {"events": []})
    danh_sach_event = du_lieu_event.get("events", [])
    danh_sach_event.append(
        {
            "message_id": tin_nhan.id,
            "channel_id": tin_nhan.channel.id,
            "so_xu": soluongxu,
            "thoi_gian_ket_thuc": thoi_gian_ket_thuc.isoformat(),
            "nguoi_tham_gia": [],
            "da_ket_thuc": False,
        }
    )
    du_lieu_event["events"] = danh_sach_event
    ghi_json(EVENTS_FILE, du_lieu_event)


# ============ FORM GHI CHÚ GỬI THÀNH VIÊN ============
class GhiChuModal(discord.ui.Modal, title="Viết Ghi Chú Gửi Thành Viên"):
    noi_dung = discord.ui.TextInput(
        label="Nội dung ghi chú",
        style=discord.TextStyle.paragraph,
        placeholder="Nhập nội dung bạn muốn gửi cho thành viên...",
        max_length=1000,
        required=True,
    )

    def __init__(self, nguoi_nhan: discord.Member):
        super().__init__()
        self.nguoi_nhan = nguoi_nhan

    async def on_submit(self, interaction: discord.Interaction):
        embed = discord.Embed(
            title="📩 Bạn có ghi chú mới từ Admin",
            description=self.noi_dung.value,
            color=discord.Color.blurple(),
        )
        embed.set_footer(text=f"Từ: {interaction.user.name}")
        try:
            await self.nguoi_nhan.send(embed=embed)
            await interaction.response.send_message(
                f"✅ Đã gửi ghi chú cho {self.nguoi_nhan.mention}.", ephemeral=True
            )
        except Exception as e:
            await interaction.response.send_message(
                f"❌ Không gửi được ghi chú (có thể họ đã tắt DM từ thành viên server). Lỗi: {e}",
                ephemeral=True,
            )


# ============ LỆNH /notead (chỉ admin - gửi ghi chú riêng) ============
@bot.tree.command(name="notead", description="[CHỈ ADMIN] Gửi ghi chú riêng cho 1 thành viên")
@app_commands.describe(user="Người nhận ghi chú")
async def notead(interaction: discord.Interaction, user: discord.Member):
    if not la_admin(interaction.user.id):
        await interaction.response.send_message("❌ Bạn không có quyền dùng lệnh này.", ephemeral=True)
        return
    await interaction.response.send_modal(GhiChuModal(user))


# ============ LỆNH /donmoinhat (chỉ admin - đơn đang chờ xử lý) ============
@bot.tree.command(name="donmoinhat", description="[CHỈ ADMIN] Xem các đơn hàng đang chờ xử lý")
async def donmoinhat(interaction: discord.Interaction):
    if not la_admin(interaction.user.id):
        await interaction.response.send_message("❌ Bạn không có quyền dùng lệnh này.", ephemeral=True)
        return

    du_lieu_don = doc_json(ORDERS_FILE, {"orders": []})
    dang_cho = [d for d in du_lieu_don.get("orders", []) if d.get("trang_thai") == "cho_xu_ly"]

    if not dang_cho:
        await interaction.response.send_message("✅ Không có đơn nào đang chờ xử lý cả.", ephemeral=True)
        return

    dang_cho = list(reversed(dang_cho))[:10]

    embed = discord.Embed(
        title="📋 Đơn Hàng Đang Chờ Xử Lý",
        description=f"{len(dang_cho)} đơn gần nhất chưa xử lý:",
        color=discord.Color.orange(),
    )
    for don in dang_cho:
        try:
            tg = datetime.fromisoformat(don.get("thoi_gian"))
            tg_vn = (tg + timedelta(hours=7)).strftime("%H:%M %d/%m/%Y")
        except Exception:
            tg_vn = "?"
        embed.add_field(
            name=f"Mã đơn #{don.get('id')} — {don.get('ten_san_pham')}",
            value=(
                f"Người mua: <@{don.get('nguoi_mua_id')}>\n"
                f"Số lượng: {don.get('so_luong')} | Tổng: {don.get('tong_tien'):,} Bxu 🪙\n"
                f"Thời gian: {tg_vn}"
            ),
            inline=False,
        )
    await interaction.response.send_message(embed=embed, ephemeral=True)


# ============ LỆNH /tonkho (chỉ admin - cập nhật số lượng tồn kho) ============
@bot.tree.command(name="tonkho", description="[CHỈ ADMIN] Cập nhật số lượng tồn kho của 1 sản phẩm")
@app_commands.describe(id="Chọn sản phẩm cần cập nhật", soluong="Số lượng tồn kho mới")
async def tonkho(interaction: discord.Interaction, id: str, soluong: int):
    if not la_admin(interaction.user.id):
        await interaction.response.send_message("❌ Bạn không có quyền dùng lệnh này.", ephemeral=True)
        return

    if soluong < 0:
        await interaction.response.send_message("Số lượng không được âm.", ephemeral=True)
        return

    san_pham = tim_san_pham_theo_id(id)
    if not san_pham:
        await interaction.response.send_message(f"Không tìm thấy sản phẩm với ID `{id}`.", ephemeral=True)
        return

    ton_kho = doc_json(TONKHO_FILE, {})
    ton_kho[str(id)] = soluong
    ghi_json(TONKHO_FILE, ton_kho)

    embed = discord.Embed(
        title="✅ Đã cập nhật tồn kho!",
        description=(
            f"📦 Sản phẩm: **{san_pham.get('ten')}** (ID: `{id}`)\n"
            f"🔢 Số lượng mới: **{soluong}**"
        ),
        color=discord.Color.green(),
    )
    await interaction.response.send_message(embed=embed, ephemeral=True)


@tonkho.autocomplete("id")
async def tonkho_autocomplete(interaction: discord.Interaction, current: str):
    du_lieu = doc_json(SHOP_FILE, {"products": []})
    san_pham_list = du_lieu.get("products", [])
    ket_qua = []
    for sp in san_pham_list:
        ma_id = str(sp.get("id", ""))
        ten = sp.get("ten", "")
        nhan = f"{ma_id} - {ten}"
        if current.lower() in nhan.lower():
            ket_qua.append(app_commands.Choice(name=nhan, value=ma_id))
    return ket_qua[:25]


# ============ LỆNH /valuesp (chỉ admin - cập nhật giá sản phẩm) ============
@bot.tree.command(
    name="valuesp",
    description="[CHỈ ADMIN] Cập nhật giá của 1 sản phẩm"
)
@app_commands.describe(
    id="ID sản phẩm cần cập nhật",
    gia="Giá Bxu mới của sản phẩm"
)
async def valuesp(interaction: discord.Interaction, id: str, gia: int):

    if not la_admin(interaction.user.id):
        await interaction.response.send_message(
            "❌ Bạn không có quyền dùng lệnh này.",
            ephemeral=True
        )
        return

    if gia < 0:
        await interaction.response.send_message(
            "❌ Giá sản phẩm không được âm.",
            ephemeral=True
        )
        return

    du_lieu_shop = doc_json(SHOP_FILE, {"products": []})
    san_pham = None

    for sp in du_lieu_shop.get("products", []):
        if str(sp.get("id")) == str(id):
            san_pham = sp
            break

    if not san_pham:
        await interaction.response.send_message(
            f"❌ Không tìm thấy sản phẩm với ID `{id}`.",
            ephemeral=True
        )
        return

    gia_cu = san_pham.get("gia", 0)

    san_pham["gia"] = gia

    ghi_json(SHOP_FILE, du_lieu_shop)

    embed = discord.Embed(
        title="✅ Đã cập nhật giá sản phẩm!",
        description=(
            f"📦 Sản phẩm: **{san_pham.get('ten', 'Không tên')}**\n"
            f"🆔 ID: `{id}`\n"
            f"💰 Giá cũ: **{gia_cu:,} Bxu**\n"
            f"💵 Giá mới: **{gia:,} Bxu**"
        ),
        color=discord.Color.green(),
    )

    await interaction.response.send_message(
        embed=embed,
        ephemeral=True
    )

    
# ============ LỆNH /dev (chỉ admin - thêm admin mới) ============

@bot.tree.command(
    name="dev",
    description="[CHỈ ADMIN] Thêm một người vào danh sách admin"
)
@app_commands.describe(
    user="Người muốn cấp quyền admin"
)
async def dev(interaction: discord.Interaction, user: discord.Member):

    if not la_admin(interaction.user.id):
        await interaction.response.send_message(
            "❌ Bạn không có quyền dùng lệnh này.",
            ephemeral=True
        )
        return

    danh_sach_admin = doc_json(ADMINS_FILE, [])

    user_id = str(user.id)

    if user_id == str(ADMIN_ID):
        await interaction.response.send_message(
            f"ℹ️ {user.mention} đã là admin gốc rồi.",
            ephemeral=True
        )
        return

    if user_id in [str(x) for x in danh_sach_admin]:
        await interaction.response.send_message(
            f"ℹ️ {user.mention} đã có quyền admin rồi.",
            ephemeral=True
        )
        return

    danh_sach_admin.append(user_id)
    ghi_json(ADMINS_FILE, danh_sach_admin)

    await interaction.response.send_message(
        f"✅ Đã thêm {user.mention} vào danh sách admin!\n"
        f"🆔 ID: `{user.id}`\n"
        f"🔐 Người này giờ có thể sử dụng các lệnh admin của bot.",
        ephemeral=True
    )
    
    
# ============ LỆNH /themsp (chỉ admin - thêm sản phẩm) ============
@bot.tree.command(name="themsp", description="[CHỈ ADMIN] Thêm sản phẩm mới vào cửa hàng")
@app_commands.describe(
    id="ID sản phẩm (không được trùng với ID đã có)",
    ten="Tên sản phẩm",
    gia="Giá bán (Bxu 🪙)",
    mota="Mô tả thêm (không bắt buộc)",
)
async def themsp(interaction: discord.Interaction, id: str, ten: str, gia: int, mota: str = ""):
    if not la_admin(interaction.user.id):
        await interaction.response.send_message("❌ Bạn không có quyền dùng lệnh này.", ephemeral=True)
        return

    if gia <= 0:
        await interaction.response.send_message("Giá phải lớn hơn 0 nhé.", ephemeral=True)
        return

    du_lieu = doc_json(SHOP_FILE, {"products": []})
    san_pham_list = du_lieu.get("products", [])

    if tim_san_pham_theo_id(id):
        await interaction.response.send_message(
            f"⚠️ ID `{id}` đã tồn tại rồi, dùng ID khác nhé.", ephemeral=True
        )
        return

    san_pham_moi = {"id": id, "ten": ten, "gia": gia}
    if mota:
        san_pham_moi["mo_ta"] = mota

    san_pham_list.append(san_pham_moi)
    du_lieu["products"] = san_pham_list
    ghi_json(SHOP_FILE, du_lieu)

    embed = discord.Embed(
        title="✅ Đã thêm sản phẩm mới!",
        description=(
            f"🆔 ID: `{id}`\n"
            f"📦 Tên: **{ten}**\n"
            f"💰 Giá: **{gia:,} Bxu 🪙**"
            + (f"\n📝 Mô tả: {mota}" if mota else "")
        ),
        color=discord.Color.green(),
    )
    await interaction.response.send_message(embed=embed)


# ============ LỆNH /xoaxu (chỉ admin - trừ xu) ============
@bot.tree.command(name="xoaxu", description="[CHỈ ADMIN] Trừ Bxu 🪙 của một thành viên")
@app_commands.describe(user="Thành viên muốn trừ Bxu 🪙", soluong="Số Bxu 🪙 muốn trừ")
async def xoaxu(interaction: discord.Interaction, user: discord.Member, soluong: int):
    if not la_admin(interaction.user.id):
        await interaction.response.send_message("❌ Bạn không có quyền dùng lệnh này.", ephemeral=True)
        return

    if soluong <= 0:
        await interaction.response.send_message("Số Bxu 🪙 phải lớn hơn 0 nhé.", ephemeral=True)
        return

    du_lieu = doc_json(ECONOMY_FILE, {})
    user_id = str(user.id)
    thong_tin_user = lay_thong_tin_user(du_lieu, user_id)
    xu_truoc = thong_tin_user.get("xu", 0)
    thong_tin_user["xu"] = max(0, xu_truoc - soluong)
    du_lieu[user_id] = thong_tin_user
    ghi_json(ECONOMY_FILE, du_lieu)

    embed = discord.Embed(
        title="✂️ Đã trừ Bxu 🪙!",
        description=(
            f"Đã trừ **{soluong:,} Bxu 🪙** của {user.mention}\n"
            f"Số Bxu 🪙 hiện có của {user.mention}: **{thong_tin_user['xu']:,} Bxu 🪙**"
        ),
        color=discord.Color.dark_red(),
    )
    await interaction.response.send_message(embed=embed)


# ============ LỆNH /ban (chỉ admin - cấm dùng lệnh kiếm xu) ============
@bot.tree.command(name="ban", description="[CHỈ ADMIN] Cấm 1 thành viên dùng các lệnh kiếm Bxu 🪙")
@app_commands.describe(user="Thành viên muốn cấm", lydo="Lý do (không bắt buộc)")
async def ban(interaction: discord.Interaction, user: discord.Member, lydo: str = "Không có lý do"):
    if not la_admin(interaction.user.id):
        await interaction.response.send_message("❌ Bạn không có quyền dùng lệnh này.", ephemeral=True)
        return

    du_lieu = doc_json(BANNED_FILE, {})
    user_id = str(user.id)

    if user_id in du_lieu:
        await interaction.response.send_message(f"⚠️ {user.mention} đã bị cấm từ trước rồi.", ephemeral=True)
        return

    du_lieu[user_id] = {
        "ly_do": lydo,
        "thoi_gian": datetime.now(timezone.utc).isoformat(),
    }
    ghi_json(BANNED_FILE, du_lieu)

    embed = discord.Embed(
        title="🚫 Đã cấm thành viên!",
        description=(
            f"{user.mention} không còn dùng được các lệnh kiếm Bxu 🪙 nữa (/dnhn, /nhapcode, tham gia event...).\n"
            f"Lý do: {lydo}"
        ),
        color=discord.Color.dark_grey(),
    )
    await interaction.response.send_message(embed=embed)


# ============ LỆNH /unban (chỉ admin - bỏ cấm) ============
@bot.tree.command(name="unban", description="[CHỈ ADMIN] Bỏ cấm cho 1 thành viên")
@app_commands.describe(user="Thành viên muốn bỏ cấm")
async def unban(interaction: discord.Interaction, user: discord.Member):
    if not la_admin(interaction.user.id):
        await interaction.response.send_message("❌ Bạn không có quyền dùng lệnh này.", ephemeral=True)
        return

    du_lieu = doc_json(BANNED_FILE, {})
    user_id = str(user.id)

    if user_id not in du_lieu:
        await interaction.response.send_message(f"{user.mention} hiện không bị cấm.", ephemeral=True)
        return

    del du_lieu[user_id]
    ghi_json(BANNED_FILE, du_lieu)

    embed = discord.Embed(
        title="✅ Đã bỏ cấm!",
        description=f"{user.mention} có thể dùng lại các lệnh kiếm Bxu 🪙 bình thường.",
        color=discord.Color.green(),
    )
    await interaction.response.send_message(embed=embed)


# ============ LỆNH /botchat (chỉ admin - cho bot gửi tin nhắn) ============
@bot.tree.command(name="botchat", description="[CHỈ ADMIN] Cho bot gửi tin nhắn tới 1 kênh bạn chọn")
@app_commands.describe(noidung="Nội dung bot sẽ gửi", guiden="Kênh muốn gửi tới")
async def botchat(interaction: discord.Interaction, noidung: str, guiden: discord.TextChannel):
    if not la_admin(interaction.user.id):
        await interaction.response.send_message("❌ Bạn không có quyền dùng lệnh này.", ephemeral=True)
        return

    try:
        await guiden.send(noidung)
        await interaction.response.send_message(f"✅ Đã gửi tin nhắn tới {guiden.mention}.", ephemeral=True)
    except Exception as e:
        await interaction.response.send_message(f"❌ Không gửi được tin nhắn: {e}", ephemeral=True)
        
# ============ MODAL /tbaoweb ============

class ModalSuaThongBaoWeb(discord.ui.Modal, title="Viết Ghi Chú Của Bạn"):

    noi_dung = discord.ui.TextInput(
        label="Nội dung thông báo",
        style=discord.TextStyle.paragraph,
        placeholder="Nhập nội dung thông báo...",
        required=True,
        max_length=4000,
    )

    def __init__(self, noi_dung_cu=""):
        super().__init__()

        # Hiện thông báo cũ trong ô nhập
        self.noi_dung.default = noi_dung_cu

    async def on_submit(self, interaction: discord.Interaction):

        if not la_admin(interaction.user.id):
            await interaction.response.send_message(
                "❌ Bạn không có quyền sử dụng chức năng này.",
                ephemeral=True
            )
            return

        noi_dung_moi = self.noi_dung.value.strip()

        if not noi_dung_moi:
            await interaction.response.send_message(
                "❌ Nội dung thông báo không được để trống.",
                ephemeral=True
            )
            return

        ghi_json(THONGBAO_FILE, {
            "noi_dung": noi_dung_moi
        })

        await interaction.response.send_message(
            "✅ Đã cập nhật thông báo trên web!",
            ephemeral=True
        )


@bot.tree.command(
    name="tbaoweb",
    description="[CHỈ ADMIN] Chỉnh sửa thông báo hiển thị trên web"
)
async def tbaoweb(interaction: discord.Interaction):

    if not la_admin(interaction.user.id):
        await interaction.response.send_message(
            "❌ Bạn không có quyền dùng lệnh này.",
            ephemeral=True
        )
        return

    # Lấy thông báo hiện tại
    du_lieu = doc_json(
        THONGBAO_FILE,
        {
            "noi_dung": "🎉 Chào mừng bạn đến với Nab Store!"
        }
    )

    noi_dung_cu = du_lieu.get("noi_dung", "")

    # Mở form chỉnh sửa
    modal = ModalSuaThongBaoWeb(noi_dung_cu)

    await interaction.response.send_modal(modal)
    

# ============ THAY THẾ: lệnh /chuyenbxu ============
CHUYENBXU_FILE = "chuyenbxu.json"
LOG_CHUYENBXU_CHANNEL_ID = os.getenv("LOG_CHUYENBXU_CHANNEL_ID")
@bot.tree.command(name="chuyenbxu", description="Chuyển Bxu 🪙 cho thành viên khác (admin có thể chuyển cho cả 1 role)")
@app_commands.describe(
    soluong="Số Bxu 🪙 muốn chuyển (cho mỗi người nếu dùng role)",
    nguoinhan="Người nhận Bxu 🪙 (để trống nếu admin dùng role)",
    role="[CHỈ ADMIN] Chuyển cho TẤT CẢ thành viên có role này",
)
async def chuyenbxu(interaction: discord.Interaction, soluong: int, nguoinhan: discord.Member = None, role: discord.Role = None):
    if la_bi_cam(interaction.user.id):
        await interaction.response.send_message("🚫 Bạn đang bị cấm dùng lệnh này.", ephemeral=True)
        return

    if soluong <= 0:
        await interaction.response.send_message("Số Bxu 🪙 phải lớn hơn 0 nhé.", ephemeral=True)
        return

    if role is not None and not la_admin(interaction.user.id):
        await interaction.response.send_message("🚫 Chỉ admin mới được chuyển Bxu 🪙 cho cả 1 role.", ephemeral=True)
        return

    if not nguoinhan and not role:
        await interaction.response.send_message("Bạn cần chọn 1 người nhận hoặc 1 role (admin).", ephemeral=True)
        return

    if nguoinhan and role:
        await interaction.response.send_message("Chỉ chọn 1 trong 2: nguoinhan HOẶC role, không chọn cả hai.", ephemeral=True)
        return

    du_lieu = doc_json(ECONOMY_FILE, {})
    nguoi_gui_id = str(interaction.user.id)
    thong_tin_gui = lay_thong_tin_user(du_lieu, nguoi_gui_id)
    xu_hien_co = thong_tin_gui.get("xu", 0)

    # ---- Chuyển cho 1 người (member thường và admin đều dùng được) ----
    if nguoinhan:
        if nguoinhan.id == interaction.user.id:
            await interaction.response.send_message("Bạn không thể tự chuyển Bxu 🪙 cho chính mình.", ephemeral=True)
            return
        if nguoinhan.bot:
            await interaction.response.send_message("Không thể chuyển Bxu 🪙 cho bot.", ephemeral=True)
            return
        if xu_hien_co < soluong:
            await interaction.response.send_message(
                f"Bạn không đủ Bxu 🪙! Cần **{soluong:,} Bxu 🪙**, bạn hiện có **{xu_hien_co:,} Bxu 🪙**.", ephemeral=True
            )
            return

        nguoi_nhan_id = str(nguoinhan.id)
        thong_tin_gui["xu"] = xu_hien_co - soluong
        du_lieu[nguoi_gui_id] = thong_tin_gui

        thong_tin_nhan = lay_thong_tin_user(du_lieu, nguoi_nhan_id)
        thong_tin_nhan["xu"] = thong_tin_nhan.get("xu", 0) + soluong
        du_lieu[nguoi_nhan_id] = thong_tin_nhan
        ghi_json(ECONOMY_FILE, du_lieu)

        du_lieu_gd = doc_json(CHUYENBXU_FILE, {"giao_dich": []})
        danh_sach_gd = du_lieu_gd.get("giao_dich", [])
        ma_gd = lay_id_don_moi(danh_sach_gd)
        bay_gio = datetime.now(timezone.utc)
        danh_sach_gd.append({
            "id": ma_gd, "nguoi_gui_id": nguoi_gui_id, "nguoi_nhan_id": nguoi_nhan_id,
            "so_luong": soluong, "thoi_gian": bay_gio.isoformat(),
        })
        du_lieu_gd["giao_dich"] = danh_sach_gd
        ghi_json(CHUYENBXU_FILE, du_lieu_gd)

        embed = discord.Embed(
            title="✅ Chuyển Bxu 🪙 thành công!",
            description=(
                f"Bạn đã chuyển **{soluong:,} Bxu 🪙** cho {nguoinhan.mention}\n"
                f"Số Bxu 🪙 còn lại: **{thong_tin_gui['xu']:,} Bxu 🪙**"
            ),
            color=discord.Color.blue(),
        )
        embed.set_footer(text=f"Mã giao dịch: {ma_gd}")
        await interaction.response.send_message(embed=embed, ephemeral=True)

        try:
            await nguoinhan.send(f"🎁 Bạn vừa nhận được **{soluong:,} Bxu 🪙** từ {interaction.user.mention}!\nMã giao dịch: {ma_gd}")
        except Exception as e:
            print(f"Không gửi được DM cho người nhận chuyển Bxu: {e}")

        if LOG_CHUYENBXU_CHANNEL_ID:
            try:
                kenh_log = bot.get_channel(int(LOG_CHUYENBXU_CHANNEL_ID)) or await bot.fetch_channel(int(LOG_CHUYENBXU_CHANNEL_ID))
                thoi_gian_vn = (bay_gio + timedelta(hours=7)).strftime("%H:%M:%S ngày %d/%m/%Y")
                embed_log = discord.Embed(title="🔄 CHUYỂN BXU GIỮA THÀNH VIÊN", color=discord.Color.blue())
                embed_log.add_field(name="🆔 Mã giao dịch", value=f"`{ma_gd}`", inline=False)
                embed_log.add_field(name="📤 Người gửi", value=f"{interaction.user.mention} (`{nguoi_gui_id}`)", inline=True)
                embed_log.add_field(name="📥 Người nhận", value=f"{nguoinhan.mention} (`{nguoi_nhan_id}`)", inline=True)
                embed_log.add_field(name="💰 Số lượng", value=f"{soluong:,} Bxu 🪙", inline=True)
                embed_log.set_footer(text=thoi_gian_vn)
                await kenh_log.send(embed=embed_log)
            except Exception as e:
                print(f"Không gửi được log chuyển Bxu: {e}")
        return

    # ---- Chuyển cho cả 1 role (chỉ admin) ----
    thanh_vien_nhan = [m for m in role.members if not m.bot and m.id != interaction.user.id]
    if not thanh_vien_nhan:
        await interaction.response.send_message(f"Role {role.mention} không có thành viên nào để chuyển (không tính bot/chính bạn).", ephemeral=True)
        return

    tong_can = soluong * len(thanh_vien_nhan)
    if xu_hien_co < tong_can:
        await interaction.response.send_message(
            f"Bạn không đủ Bxu 🪙! Cần tổng **{tong_can:,} Bxu 🪙** ({soluong:,} x {len(thanh_vien_nhan)} người), bạn hiện có **{xu_hien_co:,} Bxu 🪙**.",
            ephemeral=True,
        )
        return

    thong_tin_gui["xu"] = xu_hien_co - tong_can
    du_lieu[nguoi_gui_id] = thong_tin_gui

    for m in thanh_vien_nhan:
        uid = str(m.id)
        tt = lay_thong_tin_user(du_lieu, uid)
        tt["xu"] = tt.get("xu", 0) + soluong
        du_lieu[uid] = tt
    ghi_json(ECONOMY_FILE, du_lieu)

    embed = discord.Embed(
        title="✅ Chuyển Bxu 🪙 hàng loạt thành công!",
        description=(
            f"Đã chuyển **{soluong:,} Bxu 🪙** cho **{len(thanh_vien_nhan)}** thành viên có role {role.mention}\n"
            f"Tổng đã trừ: **{tong_can:,} Bxu 🪙**\n"
            f"Số Bxu 🪙 còn lại: **{thong_tin_gui['xu']:,} Bxu 🪙**"
        ),
        color=discord.Color.blue(),
    )
    await interaction.response.send_message(embed=embed, ephemeral=True)

    if LOG_CHUYENBXU_CHANNEL_ID:
        try:
            kenh_log = bot.get_channel(int(LOG_CHUYENBXU_CHANNEL_ID)) or await bot.fetch_channel(int(LOG_CHUYENBXU_CHANNEL_ID))
            embed_log = discord.Embed(title="🔄 CHUYỂN BXU CHO ROLE (admin)", color=discord.Color.blue())
            embed_log.add_field(name="📤 Người gửi", value=interaction.user.mention, inline=True)
            embed_log.add_field(name="🎯 Role", value=role.mention, inline=True)
            embed_log.add_field(name="👥 Số người nhận", value=str(len(thanh_vien_nhan)), inline=True)
            embed_log.add_field(name="💰 Mỗi người", value=f"{soluong:,} Bxu 🪙", inline=True)
            await kenh_log.send(embed=embed_log)
        except Exception as e:
            print(f"Không gửi được log chuyển Bxu cho role: {e}")
                    
            
# ============ LỆNH /tangxu (chỉ admin) - tặng cho member hoặc cả 1 role ============
@bot.tree.command(name="tangxu", description="[CHỈ ADMIN] Tặng Bxu 🪙 cho 1 thành viên hoặc cả 1 role")
@app_commands.describe(
    soluong="Số Bxu 🪙 muốn tặng",
    user="Thành viên muốn tặng (để trống nếu chọn role)",
    role="Role muốn tặng cho TẤT CẢ thành viên có role này (để trống nếu chọn user)",
)
async def tangxu(interaction: discord.Interaction, soluong: int, user: discord.Member = None, role: discord.Role = None):
    if not la_admin(interaction.user.id):
        await interaction.response.send_message("❌ Bạn không có quyền dùng lệnh này.", ephemeral=True)
        return

    if soluong <= 0:
        await interaction.response.send_message("Số Bxu 🪙 phải lớn hơn 0 nhé.", ephemeral=True)
        return

    if not user and not role:
        await interaction.response.send_message("Bạn cần chọn 1 thành viên hoặc 1 role để tặng.", ephemeral=True)
        return

    if user and role:
        await interaction.response.send_message("Chỉ chọn 1 trong 2: user HOẶC role, không chọn cả hai.", ephemeral=True)
        return

    du_lieu = doc_json(ECONOMY_FILE, {})

    if user:
        user_id = str(user.id)
        thong_tin_user = lay_thong_tin_user(du_lieu, user_id)
        thong_tin_user["xu"] = thong_tin_user.get("xu", 0) + soluong
        du_lieu[user_id] = thong_tin_user
        ghi_json(ECONOMY_FILE, du_lieu)

        embed = discord.Embed(
            title="🎁 Tặng Bxu 🪙 thành công!",
            description=(
                f"Đã tặng **{soluong:,} Bxu 🪙** cho {user.mention}\n"
                f"Số Bxu 🪙 hiện có của {user.mention}: **{thong_tin_user['xu']:,} Bxu 🪙**"
            ),
            color=discord.Color.purple(),
        )
        await interaction.response.send_message(embed=embed)
    else:
        thanh_vien_nhan = [m for m in role.members if not m.bot]
        if not thanh_vien_nhan:
            await interaction.response.send_message(
                f"Role {role.mention} hiện không có thành viên nào (không tính bot).", ephemeral=True
            )
            return

        for m in thanh_vien_nhan:
            uid = str(m.id)
            tt = lay_thong_tin_user(du_lieu, uid)
            tt["xu"] = tt.get("xu", 0) + soluong
            du_lieu[uid] = tt
        ghi_json(ECONOMY_FILE, du_lieu)

        embed = discord.Embed(
            title="🎁 Tặng Bxu 🪙 hàng loạt thành công!",
            description=f"Đã tặng **{soluong:,} Bxu 🪙** cho **{len(thanh_vien_nhan)}** thành viên có role {role.mention}",
            color=discord.Color.purple(),
        )
        await interaction.response.send_message(embed=embed)


# ============ LỆNH /offbot (chỉ admin - tắt trạng thái kênh trước khi tắt bot) ============
@bot.tree.command(name="offbot", description="[CHỈ ADMIN] Đổi kênh trạng thái sang đỏ trước khi tắt bot")
async def offbot(interaction: discord.Interaction):
    if not la_admin(interaction.user.id):
        await interaction.response.send_message("❌ Bạn không có quyền dùng lệnh này.", ephemeral=True)
        return

    await interaction.response.defer(ephemeral=True)
    await cap_nhat_kenh_trang_thai(TEN_KENH_OFFLINE)
    await interaction.followup.send("🔴 Đã đổi kênh trạng thái sang đỏ. Giờ bạn có thể tắt bot trên Replit.", ephemeral=True)

# ============ WEB API PHẦN 1: SETUP + LOGIN + SHOP + DNHN + BXH ============
# Cần cài thêm: pip install flask flask-cors
import asyncio
from flask import Flask, request, jsonify
from flask_cors import CORS
from threading import Thread, Lock

app_web = Flask(__name__)
CORS(app_web)  # cho phép web (GitHub Pages) gọi API này


def tim_user_theo_token(token: str):
    """Tìm user_id ứng với 1 token. Trả về None nếu không có."""
    du_lieu_token = doc_json(NABTOKEN_FILE, {})
    for user_id, thong_tin in du_lieu_token.items():
        if thong_tin.get("token") == token:
            return user_id
    return None


def lay_token_tu_request():
    """Lấy token từ header Authorization: Bearer <token>"""
    auth = request.headers.get("Authorization", "")
    if auth.startswith("Bearer "):
        return auth[len("Bearer "):].strip()
    return None


def goi_async_tu_flask(coro, timeout=10):
    """Chạy 1 coroutine (hàm async của bot, VD: gửi DM) từ trong Flask (thread khác).
    Dùng khi API cần bot làm việc gì đó liên quan Discord (DM, mention, v.v)."""
    future = asyncio.run_coroutine_threadsafe(coro, bot.loop)
    try:
        return future.result(timeout=timeout)
    except Exception as e:
        print(f"Lỗi khi gọi async từ Flask: {e}")
        return None


# ---- POST /api/login : kiểm tra token có hợp lệ không ----
@app_web.route("/api/login", methods=["POST"])
def api_login():
    body = request.get_json(silent=True) or {}
    token = body.get("token", "").strip()
    if not token:
        return jsonify({"error": "Thiếu token"}), 400

    user_id = tim_user_theo_token(token)
    if not user_id:
        return jsonify({"error": "Token không hợp lệ"}), 401

    du_lieu_economy = doc_json(ECONOMY_FILE, {})
    thong_tin_user = lay_thong_tin_user(du_lieu_economy, user_id)

    ten_hien_thi = user_id
    user_obj = bot.get_user(int(user_id))
    if user_obj:
        ten_hien_thi = user_obj.name

    return jsonify({
        "user_id": user_id,
        "username": ten_hien_thi,
        "xu": thong_tin_user.get("xu", 0),
        "streak": thong_tin_user.get("streak_diem_danh", 0),
    })


# ---- GET /api/shop : danh sách sản phẩm ----
@app_web.route("/api/shop", methods=["GET"])
def api_shop():
    du_lieu_shop = doc_json(SHOP_FILE, {"products": []})
    ton_kho = doc_json(TONKHO_FILE, {})
    san_pham = du_lieu_shop.get("products", [])

    ket_qua = []
    for sp in san_pham:
        muc = dict(sp)
        muc["ton_kho"] = ton_kho.get(str(sp.get("id")))
        ket_qua.append(muc)

    return jsonify({"products": ket_qua})


# ---- GET /api/me : thông tin tài khoản (cần token) ----
@app_web.route("/api/me", methods=["GET"])
def api_me():
    token = lay_token_tu_request()
    user_id = tim_user_theo_token(token) if token else None
    if not user_id:
        return jsonify({"error": "Token không hợp lệ"}), 401

    du_lieu_economy = doc_json(ECONOMY_FILE, {})
    thong_tin_user = lay_thong_tin_user(du_lieu_economy, user_id)

    return jsonify({
        "user_id": user_id,
        "xu": thong_tin_user.get("xu", 0),
        "streak": thong_tin_user.get("streak_diem_danh", 0),
    })


# ---- POST /api/dnhn : điểm danh qua web (dùng lại đúng logic của lệnh /dnhn) ----
@app_web.route("/api/dnhn", methods=["POST"])
def api_dnhn():
    token = lay_token_tu_request()
    user_id = tim_user_theo_token(token) if token else None
    if not user_id:
        return jsonify({"error": "Token không hợp lệ"}), 401

    if la_bi_cam(user_id):
        return jsonify({"error": "Bạn đang bị cấm dùng lệnh kiếm Bxu"}), 403

    du_lieu = doc_json(ECONOMY_FILE, {})
    bay_gio = datetime.now(timezone.utc)
    gio_vn = bay_gio + timedelta(hours=7)
    thong_tin_user = lay_thong_tin_user(du_lieu, user_id)

    ma_phien_hien_tai, thoi_gian_reset_tiep = lay_phien_diem_danh(gio_vn)
    phien_da_diem_danh = thong_tin_user.get("phien_diem_danh_cuoi")

    if phien_da_diem_danh == ma_phien_hien_tai:
        con_lai = thoi_gian_reset_tiep - gio_vn
        gio = con_lai.seconds // 3600
        phut = (con_lai.seconds % 3600) // 60
        return jsonify({
            "error": f"Bạn đã điểm danh hôm nay rồi. Quay lại sau {gio} giờ {phut} phút."
        }), 400

    streak_cu = thong_tin_user.get("streak_diem_danh", 0)
    if phien_da_diem_danh:
        try:
            ngay_truoc = datetime.strptime(phien_da_diem_danh, "%Y-%m-%d")
            ngay_du_kien_tiep_theo = (ngay_truoc + timedelta(days=1)).strftime("%Y-%m-%d")
            streak_moi = streak_cu + 1 if ngay_du_kien_tiep_theo == ma_phien_hien_tai else 1
        except Exception:
            streak_moi = 1
    else:
        streak_moi = 1

    xu_nhan_duoc = tinh_xu_theo_streak(streak_moi)
    thong_tin_user["xu"] = thong_tin_user.get("xu", 0) + xu_nhan_duoc
    thong_tin_user["phien_diem_danh_cuoi"] = ma_phien_hien_tai
    thong_tin_user["streak_diem_danh"] = streak_moi
    du_lieu[user_id] = thong_tin_user
    ghi_json(ECONOMY_FILE, du_lieu)

    return jsonify({
        "xu_nhan_duoc": xu_nhan_duoc,
        "streak": streak_moi,
        "tong_xu": thong_tin_user["xu"],
    })


# ---- GET /api/bxh : bảng xếp hạng ----
@app_web.route("/api/bxh", methods=["GET"])
def api_bxh():
    du_lieu = doc_json(ECONOMY_FILE, {})
    danh_sach = [
        {"user_id": uid, "xu": tt.get("xu", 0)}
        for uid, tt in du_lieu.items()
        if not la_admin(uid) and tt.get("xu", 0) > 0
    ]
    danh_sach.sort(key=lambda x: x["xu"], reverse=True)
    top = danh_sach[:10]

    for muc in top:
        user_obj = bot.get_user(int(muc["user_id"]))
        muc["username"] = user_obj.name if user_obj else muc["user_id"]

    return jsonify({"top": top})


# ============ API NẠP THẺ / NẠP BANK / THÔNG TIN CÁ NHÂN (web) ============
async def _gui_thong_bao_napthe_admin(nguoi_gui_id: str, loai_the: str, menh_gia: int, ma_the: str, so_seri: str, ma_yeu_cau: str):
    if not ADMIN_ID:
        return
    try:
        admin_user = await bot.fetch_user(int(ADMIN_ID))
        nguoi_gui_obj = bot.get_user(int(nguoi_gui_id))
        ten_nguoi_gui = nguoi_gui_obj.mention if nguoi_gui_obj else f"<@{nguoi_gui_id}>"
        embed = discord.Embed(
            title="💳 Có yêu cầu nạp thẻ mới! (qua Web)",
            description=(
                f"**Người gửi:** {ten_nguoi_gui}\n"
                f"**Loại thẻ:** {loai_the}\n"
                f"**Mệnh giá:** {menh_gia:,}đ\n"
                f"**Mã thẻ:** `{ma_the}`\n"
                f"**Số seri:** `{so_seri}`"
            ),
            color=discord.Color.blue(),
        )
        embed.set_footer(text=f"Mã Yêu Cầu: {ma_yeu_cau}")
        await admin_user.send(embed=embed, view=NapTheActionView())
    except Exception as e:
        print(f"Không gửi được thông báo nạp thẻ (web) cho admin: {e}")


@app_web.route("/api/napthe", methods=["POST"])
def api_napthe():
    token = lay_token_tu_request()
    user_id = tim_user_theo_token(token) if token else None
    if not user_id:
        return jsonify({"error": "Token không hợp lệ"}), 401

    body = request.get_json(silent=True) or {}
    loai_the = str(body.get("loai_the", "")).strip().upper()
    menh_gia = body.get("menh_gia", 0)
    ma_the = str(body.get("ma_the", "")).strip()
    so_seri = str(body.get("so_seri", "")).strip()

    if loai_the not in DANH_SACH_NHA_MANG:
        return jsonify({"error": "Loại thẻ không hợp lệ"}), 400
    if menh_gia not in DANH_SACH_MENH_GIA:
        return jsonify({"error": "Mệnh giá không hợp lệ"}), 400
    if not ma_the or not so_seri:
        return jsonify({"error": "Thiếu mã thẻ hoặc số seri"}), 400

    du_lieu = doc_json(NAPTHE_FILE, {"requests": []})
    danh_sach = du_lieu.get("requests", [])
    ma_yeu_cau = lay_id_don_moi(danh_sach)

    danh_sach.append({
        "id": ma_yeu_cau,
        "user_id": int(user_id),
        "ten_user": "web",
        "loai_the": loai_the,
        "menh_gia": menh_gia,
        "ma_the": ma_the,
        "so_seri": so_seri,
        "thoi_gian": datetime.now(timezone.utc).isoformat(),
        "trang_thai": "cho_xu_ly",
    })
    du_lieu["requests"] = danh_sach
    ghi_json(NAPTHE_FILE, du_lieu)

    goi_async_tu_flask(_gui_thong_bao_napthe_admin(user_id, loai_the, menh_gia, ma_the, so_seri, ma_yeu_cau))

    return jsonify({"ma_yeu_cau": ma_yeu_cau})


async def _gui_thong_bao_napbank_admin(nguoi_gui_id: str, so_tien: int, ghi_chu: str, ma_yeu_cau: str):
    if not ADMIN_ID:
        return
    try:
        admin_user = await bot.fetch_user(int(ADMIN_ID))
        nguoi_gui_obj = bot.get_user(int(nguoi_gui_id))
        ten_nguoi_gui = nguoi_gui_obj.mention if nguoi_gui_obj else f"<@{nguoi_gui_id}>"
        embed = discord.Embed(
            title="🏦 Có yêu cầu nạp bank mới! (qua Web)",
            description=f"**Người gửi:** {ten_nguoi_gui}\n**Số tiền:** {so_tien:,}đ\n**Ghi chú:** {ghi_chu or 'Không có'}",
            color=discord.Color.blue(),
        )
        embed.set_footer(text=f"Mã Yêu Cầu: {ma_yeu_cau}")
        await admin_user.send(embed=embed, view=NapBankActionView())
    except Exception as e:
        print(f"Không gửi được thông báo nạp bank (web) cho admin: {e}")


@app_web.route("/api/napbank", methods=["POST"])
def api_napbank():
    token = lay_token_tu_request()
    user_id = tim_user_theo_token(token) if token else None
    if not user_id:
        return jsonify({"error": "Token không hợp lệ"}), 401

    body = request.get_json(silent=True) or {}
    so_tien = body.get("so_tien", 0)
    ghi_chu = str(body.get("ghi_chu", "")).strip()

    if not isinstance(so_tien, int) or so_tien <= 0:
        return jsonify({"error": "Số tiền không hợp lệ"}), 400

    du_lieu = doc_json(NAPBANK_FILE, {"requests": []})
    danh_sach = du_lieu.get("requests", [])
    ma_yeu_cau = lay_id_don_moi(danh_sach)

    danh_sach.append({
        "id": ma_yeu_cau,
        "user_id": int(user_id),
        "ten_user": "web",
        "so_tien": so_tien,
        "ghi_chu": ghi_chu,
        "thoi_gian": datetime.now(timezone.utc).isoformat(),
        "trang_thai": "cho_xu_ly",
    })
    du_lieu["requests"] = danh_sach
    ghi_json(NAPBANK_FILE, du_lieu)

    goi_async_tu_flask(_gui_thong_bao_napbank_admin(user_id, so_tien, ghi_chu, ma_yeu_cau))

    return jsonify({"ma_yeu_cau": ma_yeu_cau})


@app_web.route("/api/ttcn", methods=["GET"])
def api_ttcn():
    token = lay_token_tu_request()
    user_id = tim_user_theo_token(token) if token else None
    if not user_id:
        return jsonify({"error": "Token không hợp lệ"}), 401

    du_lieu_economy = doc_json(ECONOMY_FILE, {})
    thong_tin_user = lay_thong_tin_user(du_lieu_economy, user_id)
    xu = thong_tin_user.get("xu", 0)
    streak = thong_tin_user.get("streak_diem_danh", 0)

    danh_sach_xep_hang = sorted(
        [(uid, tt.get("xu", 0)) for uid, tt in du_lieu_economy.items() if not la_admin(uid)],
        key=lambda x: x[1], reverse=True,
    )
    hang = None
    for i, (uid, _) in enumerate(danh_sach_xep_hang):
        if uid == user_id:
            hang = i + 1
            break

    du_lieu_don = doc_json(ORDERS_FILE, {"orders": []})
    so_don = sum(1 for d in du_lieu_don.get("orders", []) if str(d.get("nguoi_mua_id")) == user_id)

    return jsonify({"xu": xu, "streak": streak, "hang": hang, "so_don": so_don})
            
# ============ THÔNG BÁO ĐĂNG NHẬP TRÊN WEB ============

@app_web.route("/api/thongbao", methods=["GET"])
def api_thongbao():
    du_lieu = doc_json(THONGBAO_FILE, {
        "noi_dung": "🎉 Chào mừng bạn đến với Nab Store!"
    })

    return jsonify({
        "noi_dung": du_lieu.get("noi_dung", "")
    })


# ============ TÊN HIỂN THỊ RIÊNG CHO WEB ============
WEBTEN_FILE = "webten.json"


@app_web.route("/api/tenweb", methods=["GET"])
def api_tenweb_get():
    token = lay_token_tu_request()
    user_id = tim_user_theo_token(token) if token else None
    if not user_id:
        return jsonify({"error": "Token không hợp lệ"}), 401

    du_lieu = doc_json(WEBTEN_FILE, {})
    return jsonify({"ten_web": du_lieu.get(user_id)})


@app_web.route("/api/tenweb", methods=["POST"])
def api_tenweb_set():
    token = lay_token_tu_request()
    user_id = tim_user_theo_token(token) if token else None
    if not user_id:
        return jsonify({"error": "Token không hợp lệ"}), 401

    body = request.get_json(silent=True) or {}
    ten = str(body.get("ten", "")).strip()

    if not ten or len(ten) > 30:
        return jsonify({"error": "Tên phải từ 1-30 ký tự"}), 400

    du_lieu = doc_json(WEBTEN_FILE, {})
    du_lieu[user_id] = ten
    ghi_json(WEBTEN_FILE, du_lieu)

    return jsonify({"ten_web": ten})
    
def chay_flask():
  app_web.run(host="0.0.0.0", port=9285)
# ============ WEB API PHẦN 2: MUASP + LSMUA + CHUYENBXU + NHAPCODE ============
# Dán đoạn này NGAY SAU webapi_part1.py (trước dòng "def chay_flask():" của phần 1
# hoặc ngay sau nó đều được, miễn nằm trong cùng khu vực code Flask)

async def _gui_thong_bao_don_hang_admin(nguoi_mua_id: str, san_pham, soluong: int, tong_tien: int, ma_don: str):
    """Chạy trong loop của bot để gửi DM kèm nút Done/Từ chối cho admin (giống lệnh /muasp)."""
    if not ADMIN_ID:
        return
    try:
        admin_user = await bot.fetch_user(int(ADMIN_ID))
        nguoi_mua_obj = bot.get_user(int(nguoi_mua_id))
        ten_nguoi_mua = nguoi_mua_obj.mention if nguoi_mua_obj else f"<@{nguoi_mua_id}>"
        thong_bao = discord.Embed(
            title="🔔 Có đơn hàng mới! (đặt qua Web)",
            description=(
                f"**Người mua:** {ten_nguoi_mua}\n"
                f"**Sản phẩm:** {san_pham.get('ten')} (ID: {san_pham.get('id')})\n"
                f"**Số lượng:** {soluong}\n"
                f"**Tổng tiền:** {tong_tien:,} Bxu 🪙"
            ),
            color=discord.Color.orange(),
        )
        thong_bao.set_footer(text=f"ID Đơn Hàng: {ma_don}")
        await admin_user.send(embed=thong_bao, view=OrderActionView())
    except Exception as e:
        print(f"Không gửi được thông báo đơn hàng (web) cho admin: {e}")


# ---- POST /api/muasp : mua sản phẩm qua web (dùng lại đúng logic của /muasp) ----
@app_web.route("/api/muasp", methods=["POST"])
def api_muasp():
    token = lay_token_tu_request()
    user_id = tim_user_theo_token(token) if token else None
    if not user_id:
        return jsonify({"error": "Token không hợp lệ"}), 401

    body = request.get_json(silent=True) or {}
    san_pham_id = str(body.get("san_pham_id", "")).strip()
    soluong = body.get("soluong", 0)

    if not isinstance(soluong, int) or soluong <= 0:
        return jsonify({"error": "Số lượng phải lớn hơn 0"}), 400

    san_pham = tim_san_pham_theo_id(san_pham_id)
    if not san_pham:
        return jsonify({"error": f"Không tìm thấy sản phẩm ID {san_pham_id}"}), 404

    gia_don_vi = san_pham.get("gia", 0)
    tong_tien = gia_don_vi * soluong

    ton_kho = doc_json(TONKHO_FILE, {})
    so_luong_con = ton_kho.get(str(san_pham_id))
    if so_luong_con is not None and so_luong_con < soluong:
        return jsonify({"error": f"Sản phẩm chỉ còn {so_luong_con}"}), 400

    du_lieu = doc_json(ECONOMY_FILE, {})
    thong_tin_user = lay_thong_tin_user(du_lieu, user_id)
    xu_hien_co = thong_tin_user.get("xu", 0)

    la_tai_khoan_test = la_admin(user_id)
    if not la_tai_khoan_test and xu_hien_co < tong_tien:
        return jsonify({"error": f"Không đủ Bxu. Cần {tong_tien:,}, hiện có {xu_hien_co:,}"}), 400

    if not la_tai_khoan_test:
        thong_tin_user["xu"] = xu_hien_co - tong_tien
        du_lieu[user_id] = thong_tin_user
        ghi_json(ECONOMY_FILE, du_lieu)

    if so_luong_con is not None:
        ton_kho[str(san_pham_id)] = so_luong_con - soluong
        ghi_json(TONKHO_FILE, ton_kho)

    bay_gio = datetime.now(timezone.utc)
    du_lieu_don = doc_json(ORDERS_FILE, {"orders": []})
    danh_sach_don = du_lieu_don.get("orders", [])
    ma_don_moi = lay_id_don_moi(danh_sach_don)

    danh_sach_don.append({
        "id": ma_don_moi,
        "nguoi_mua_id": int(user_id),
        "ten_nguoi_mua": "web",
        "san_pham_id": san_pham_id,
        "ten_san_pham": san_pham.get("ten"),
        "so_luong": soluong,
        "tong_tien": tong_tien,
        "thoi_gian": bay_gio.isoformat(),
        "trang_thai": "cho_xu_ly",
    })
    du_lieu_don["orders"] = danh_sach_don
    ghi_json(ORDERS_FILE, du_lieu_don)

    goi_async_tu_flask(_gui_thong_bao_don_hang_admin(user_id, san_pham, soluong, tong_tien, ma_don_moi))

    return jsonify({
        "ma_don": ma_don_moi,
        "tong_tien": tong_tien,
        "xu_con_lai": thong_tin_user["xu"] if not la_tai_khoan_test else None,
    })


# ---- GET /api/lsmua : lịch sử mua hàng ----
@app_web.route("/api/lsmua", methods=["GET"])
def api_lsmua():
    token = lay_token_tu_request()
    user_id = tim_user_theo_token(token) if token else None
    if not user_id:
        return jsonify({"error": "Token không hợp lệ"}), 401

    du_lieu_don = doc_json(ORDERS_FILE, {"orders": []})
    danh_sach_don = du_lieu_don.get("orders", [])
    don_cua_toi = [d for d in danh_sach_don if str(d.get("nguoi_mua_id")) == user_id]
    don_cua_toi = list(reversed(don_cua_toi))[:10]

    return jsonify({"orders": don_cua_toi})


async def _gui_dm_nhan_chuyen_bxu(nguoi_nhan_id: str, nguoi_gui_id: str, soluong: int, ma_gd: str):
    """Chạy trong loop của bot để gửi DM báo người nhận (giống lệnh /chuyenbxu)."""
    try:
        nguoi_nhan_obj = await bot.fetch_user(int(nguoi_nhan_id))
        nguoi_gui_obj = bot.get_user(int(nguoi_gui_id))
        ten_nguoi_gui = nguoi_gui_obj.mention if nguoi_gui_obj else f"<@{nguoi_gui_id}>"
        await nguoi_nhan_obj.send(
            f"🎁 Bạn vừa nhận được **{soluong:,} Bxu 🪙** từ {ten_nguoi_gui} (qua Web)!\n"
            f"Mã giao dịch: {ma_gd}"
        )
    except Exception as e:
        print(f"Không gửi được DM chuyển Bxu (web): {e}")

    if LOG_CHUYENBXU_CHANNEL_ID:
        try:
            kenh_log = bot.get_channel(int(LOG_CHUYENBXU_CHANNEL_ID)) or await bot.fetch_channel(int(LOG_CHUYENBXU_CHANNEL_ID))
            embed_log = discord.Embed(title="🔄 CHUYỂN BXU (qua Web)", color=discord.Color.blue())
            embed_log.add_field(name="🆔 Mã giao dịch", value=f"`{ma_gd}`", inline=False)
            embed_log.add_field(name="📤 Người gửi", value=f"<@{nguoi_gui_id}>", inline=True)
            embed_log.add_field(name="📥 Người nhận", value=f"<@{nguoi_nhan_id}>", inline=True)
            embed_log.add_field(name="💰 Số lượng", value=f"{soluong:,} Bxu 🪙", inline=True)
            await kenh_log.send(embed=embed_log)
        except Exception as e:
            print(f"Không gửi được log chuyển Bxu (web): {e}")


# ---- POST /api/chuyenbxu : chuyển Bxu qua web ----
@app_web.route("/api/chuyenbxu", methods=["POST"])
def api_chuyenbxu():
    token = lay_token_tu_request()
    nguoi_gui_id = tim_user_theo_token(token) if token else None
    if not nguoi_gui_id:
        return jsonify({"error": "Token không hợp lệ"}), 401

    if la_bi_cam(nguoi_gui_id):
        return jsonify({"error": "Bạn đang bị cấm dùng chức năng này"}), 403

    body = request.get_json(silent=True) or {}
    nguoi_nhan_id = str(body.get("nguoi_nhan_id", "")).strip()
    soluong = body.get("soluong", 0)

    if not isinstance(soluong, int) or soluong <= 0:
        return jsonify({"error": "Số lượng phải lớn hơn 0"}), 400
    if not nguoi_nhan_id:
        return jsonify({"error": "Thiếu người nhận"}), 400
    if nguoi_nhan_id == nguoi_gui_id:
        return jsonify({"error": "Không thể tự chuyển cho chính mình"}), 400

    du_lieu = doc_json(ECONOMY_FILE, {})
    thong_tin_gui = lay_thong_tin_user(du_lieu, nguoi_gui_id)
    xu_hien_co = thong_tin_gui.get("xu", 0)

    if xu_hien_co < soluong:
        return jsonify({"error": f"Không đủ Bxu. Cần {soluong:,}, hiện có {xu_hien_co:,}"}), 400

    thong_tin_gui["xu"] = xu_hien_co - soluong
    du_lieu[nguoi_gui_id] = thong_tin_gui
    thong_tin_nhan = lay_thong_tin_user(du_lieu, nguoi_nhan_id)
    thong_tin_nhan["xu"] = thong_tin_nhan.get("xu", 0) + soluong
    du_lieu[nguoi_nhan_id] = thong_tin_nhan
    ghi_json(ECONOMY_FILE, du_lieu)

    du_lieu_gd = doc_json(CHUYENBXU_FILE, {"giao_dich": []})
    danh_sach_gd = du_lieu_gd.get("giao_dich", [])
    ma_gd = lay_id_don_moi(danh_sach_gd)
    danh_sach_gd.append({
        "id": ma_gd,
        "nguoi_gui_id": nguoi_gui_id,
        "nguoi_nhan_id": nguoi_nhan_id,
        "so_luong": soluong,
        "thoi_gian": datetime.now(timezone.utc).isoformat(),
    })
    du_lieu_gd["giao_dich"] = danh_sach_gd
    ghi_json(CHUYENBXU_FILE, du_lieu_gd)

    goi_async_tu_flask(_gui_dm_nhan_chuyen_bxu(nguoi_nhan_id, nguoi_gui_id, soluong, ma_gd))

    return jsonify({"ma_gd": ma_gd, "xu_con_lai": thong_tin_gui["xu"]})


# ============ THAY THẾ 3: API web /api/nhapcode (thêm check giới hạn) ============
@app_web.route("/api/nhapcode", methods=["POST"])
def api_nhapcode():
    token = lay_token_tu_request()
    user_id = tim_user_theo_token(token) if token else None
    if not user_id:
        return jsonify({"error": "Token không hợp lệ"}), 401

    if la_bi_cam(user_id):
        return jsonify({"error": "Bạn đang bị cấm dùng chức năng này"}), 403

    body = request.get_json(silent=True) or {}
    ma_chuan_hoa = str(body.get("ma", "")).strip().upper()
    if not ma_chuan_hoa:
        return jsonify({"error": "Thiếu mã code"}), 400

    du_lieu = doc_json(CODES_FILE, {})
    thong_tin_code = du_lieu.get(ma_chuan_hoa)
    if not thong_tin_code:
        return jsonify({"error": "Mã không tồn tại"}), 404

    het_han = datetime.fromisoformat(thong_tin_code["het_han"])
    if datetime.now(timezone.utc) > het_han:
        return jsonify({"error": "Mã đã hết hạn"}), 400

    da_dung = thong_tin_code.get("da_dung", [])
    gioi_han = thong_tin_code.get("gioi_han_so_nguoi")
    if gioi_han is not None and len(da_dung) >= gioi_han:
        return jsonify({"error": f"Mã đã đủ số người nhập tối đa ({gioi_han} người)"}), 400

    user_id_int = int(user_id)
    if user_id_int in da_dung:
        return jsonify({"error": "Bạn đã nhập mã này rồi"}), 400

    soluongxu = thong_tin_code.get("soluongxu", 0)
    thong_tin_code.setdefault("da_dung", []).append(user_id_int)
    du_lieu[ma_chuan_hoa] = thong_tin_code
    ghi_json(CODES_FILE, du_lieu)

    du_lieu_economy = doc_json(ECONOMY_FILE, {})
    thong_tin_user = lay_thong_tin_user(du_lieu_economy, user_id)
    thong_tin_user["xu"] = thong_tin_user.get("xu", 0) + soluongxu
    du_lieu_economy[user_id] = thong_tin_user
    ghi_json(ECONOMY_FILE, du_lieu_economy)

    return jsonify({"xu_nhan_duoc": soluongxu, "tong_xu": thong_tin_user["xu"]})
    

# Phần 2 (webapi_part2.py) sẽ nối thêm các API còn lại (muasp, lsmua, chuyenbxu, nhapcode)
# vào NGAY BÊN DƯỚI phần này. Sau khi dán đủ cả 2 phần, ở CUỐI file main.py,
# TRƯỚC dòng bot.run(TOKEN), thêm dòng: Thread(target=chay_flask).start()


# ============================================================
# WEB API: MINI GAME MEMORY
# - Dễ: 3x3 = 4 cặp + 1 ô đặc biệt, thưởng 10-25 Bxu
# - Khó: 10x10 = 50 cặp, thưởng 25-50 Bxu
# - Cooldown dùng chung: 12 giờ sau khi hoàn thành.
# - Server tự tạo bàn, tự kiểm tra nước đi và tự random phần thưởng.
# ============================================================

def _minigame_now():
    return datetime.now(timezone.utc)


def _minigame_iso(dt):
    return dt.isoformat()


def _minigame_parse_time(value):
    try:
        return datetime.fromisoformat(value)
    except Exception:
        return None


def _minigame_config(mode):
    if mode == "hard":
        return {
            "mode": "hard",
            "size": 10,
            "card_count": 100,
            "pair_count": 50,
            "reward_min": 25,
            "reward_max": 50,
            "max_moves": 600,
        }

    return {
        "mode": "easy",
        "size": 3,
        "card_count": 9,
        "pair_count": 4,
        "reward_min": 10,
        "reward_max": 25,
        "max_moves": 120,
    }


def _minigame_make_board(mode):
    cfg = _minigame_config(mode)

    # 50 ký hiệu duy nhất, đủ cho mức 10x10.
    ky_hieu = list(
        "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
        "abcdefghijklmnopqrstuvwx"
    )[:cfg["pair_count"]]

    board = []
    for symbol in ky_hieu:
        board.extend([symbol, symbol])

    if mode == "easy":
        # 3x3 là số ô lẻ, nên dùng 4 cặp + 1 ô đặc biệt ⭐.
        board.append("⭐")

    random.shuffle(board)
    return board


def _minigame_public_state(game):
    matched = [int(x) for x in game.get("matched_indices", [])]
    revealed = [int(x) for x in game.get("revealed_indices", [])]
    board = game.get("board", [])

    return {
        "game_id": game.get("game_id"),
        "mode": game.get("mode"),
        "size": game.get("size"),
        "card_count": len(board),
        "pair_count": game.get("pair_count", 0),
        "matched_indices": matched,
        "matched_cards": [
            {"index": i, "symbol": board[i]}
            for i in matched
            if 0 <= i < len(board)
        ],
        "revealed_cards": [
            {"index": i, "symbol": board[i]}
            for i in revealed
            if 0 <= i < len(board)
        ],
    }


def _minigame_find_active(games, user_id):
    for game in games.values():
        if str(game.get("user_id")) == str(user_id) and not game.get("completed"):
            return game
    return None


def _minigame_cleanup(data):
    now = _minigame_now()
    games = data.setdefault("games", {})
    cooldowns = data.setdefault("cooldowns", {})

    # Xóa phiên game quá cũ.
    for game_id in list(games.keys()):
        game = games.get(game_id, {})
        created = _minigame_parse_time(game.get("created_at", ""))
        if not created or (now - created).total_seconds() > MINIGAME_GAME_TTL_SECONDS:
            del games[game_id]

    # Dọn cooldown đã hết hạn.
    for uid in list(cooldowns.keys()):
        until = _minigame_parse_time(cooldowns.get(uid, ""))
        if not until or until <= now:
            del cooldowns[uid]


@app_web.route("/api/minigame/status", methods=["GET"])
def api_minigame_status():
    token = lay_token_tu_request()
    user_id = tim_user_theo_token(token) if token else None
    if not user_id:
        return jsonify({"error": "Token không hợp lệ"}), 401

    if la_bi_cam(user_id):
        return jsonify({"error": "Bạn đang bị cấm dùng chức năng này"}), 403

    with MINIGAME_LOCK:
        data = doc_json(MINIGAME_FILE, {"games": {}, "cooldowns": {}})
        _minigame_cleanup(data)

        cooldown_until = data.get("cooldowns", {}).get(str(user_id))
        seconds_left = 0

        if cooldown_until:
            dt = _minigame_parse_time(cooldown_until)
            if dt:
                seconds_left = max(
                    0,
                    int((dt - _minigame_now()).total_seconds())
                )

        active = _minigame_find_active(data.get("games", {}), user_id)
        ghi_json(MINIGAME_FILE, data)

    return jsonify({
        "cooldown_seconds": seconds_left,
        "active_game": _minigame_public_state(active) if active else None,
    })


@app_web.route("/api/minigame/start", methods=["POST"])
def api_minigame_start():
    token = lay_token_tu_request()
    user_id = tim_user_theo_token(token) if token else None
    if not user_id:
        return jsonify({"error": "Token không hợp lệ"}), 401

    if la_bi_cam(user_id):
        return jsonify({"error": "Bạn đang bị cấm dùng chức năng này"}), 403

    body = request.get_json(silent=True) or {}
    mode = str(body.get("mode", "easy")).strip().lower()

    if mode not in ("easy", "hard"):
        return jsonify({"error": "Mức chơi không hợp lệ"}), 400

    with MINIGAME_LOCK:
        data = doc_json(MINIGAME_FILE, {"games": {}, "cooldowns": {}})
        _minigame_cleanup(data)

        cooldown_until = data.get("cooldowns", {}).get(str(user_id))
        if cooldown_until:
            dt = _minigame_parse_time(cooldown_until)
            if dt and dt > _minigame_now():
                seconds_left = int((dt - _minigame_now()).total_seconds())
                ghi_json(MINIGAME_FILE, data)
                return jsonify({
                    "error": f"Bạn còn cooldown {seconds_left} giây.",
                    "cooldown_seconds": seconds_left,
                }), 429

        active = _minigame_find_active(data.get("games", {}), user_id)

        # Không tạo game mới nếu người dùng đã có game đang chơi.
        if active:
            public_state = _minigame_public_state(active)
            ghi_json(MINIGAME_FILE, data)
            return jsonify(public_state)

        cfg = _minigame_config(mode)
        game_id = uuid.uuid4().hex
        board = _minigame_make_board(mode)

        game = {
            "game_id": game_id,
            "user_id": str(user_id),
            "mode": mode,
            "size": cfg["size"],
            "pair_count": cfg["pair_count"],
            "board": board,
            "matched_indices": [],
            "revealed_indices": [],
            "moves": 0,
            "last_move_at": None,
            "created_at": _minigame_iso(_minigame_now()),
            "completed": False,
            "special_revealed": False,
        }

        data.setdefault("games", {})[game_id] = game
        ghi_json(MINIGAME_FILE, data)

    public_state = _minigame_public_state(game)
    public_state.update({
        "reward_min": cfg["reward_min"],
        "reward_max": cfg["reward_max"],
        "cooldown_seconds": 0,
    })
    return jsonify(public_state)


@app_web.route("/api/minigame/move", methods=["POST"])
def api_minigame_move():
    token = lay_token_tu_request()
    user_id = tim_user_theo_token(token) if token else None
    if not user_id:
        return jsonify({"error": "Token không hợp lệ"}), 401

    if la_bi_cam(user_id):
        return jsonify({"error": "Bạn đang bị cấm dùng chức năng này"}), 403

    body = request.get_json(silent=True) or {}
    game_id = str(body.get("game_id", "")).strip()

    try:
        index = int(body.get("index"))
    except Exception:
        return jsonify({"error": "Ô không hợp lệ"}), 400

    with MINIGAME_LOCK:
        data = doc_json(MINIGAME_FILE, {"games": {}, "cooldowns": {}})
        _minigame_cleanup(data)

        game = data.get("games", {}).get(game_id)

        if not game:
            ghi_json(MINIGAME_FILE, data)
            return jsonify({"error": "Phiên game không tồn tại hoặc đã hết hạn."}), 404

        if str(game.get("user_id")) != str(user_id):
            return jsonify({"error": "Bạn không sở hữu phiên game này."}), 403

        if game.get("completed"):
            return jsonify({"error": "Game này đã hoàn thành."}), 400

        board = game.get("board", [])
        if index < 0 or index >= len(board):
            return jsonify({"error": "Ô không hợp lệ."}), 400

        if index in [int(x) for x in game.get("matched_indices", [])]:
            return jsonify({"error": "Ô này đã ghép rồi."}), 400

        if index in [int(x) for x in game.get("revealed_indices", [])]:
            return jsonify({"error": "Ô này đang được mở."}), 400

        now = _minigame_now()
        last_move = _minigame_parse_time(game.get("last_move_at", ""))

        # Chặn spam request cực nhanh.
        if last_move and (now - last_move).total_seconds() < 0.12:
            return jsonify({"error": "Bạn thao tác quá nhanh, chờ một chút."}), 429

        game["last_move_at"] = _minigame_iso(now)
        game["moves"] = int(game.get("moves", 0)) + 1

        cfg = _minigame_config(game.get("mode", "easy"))

        if game["moves"] > cfg["max_moves"]:
            del data["games"][game_id]
            ghi_json(MINIGAME_FILE, data)
            return jsonify({"error": "Game đã bị hủy vì có quá nhiều nước đi."}), 400

        revealed = [int(x) for x in game.get("revealed_indices", [])]

        # Ô đặc biệt của mức Dễ.
        if board[index] == "⭐":
            game["special_revealed"] = True
            game["revealed_indices"] = [index]

            da_xong = (
                len(game.get("matched_indices", [])) == cfg["pair_count"] * 2
            )

            if da_xong:
                reward = random.randint(cfg["reward_min"], cfg["reward_max"])

                du_lieu_economy = doc_json(ECONOMY_FILE, {})
                thong_tin_user = lay_thong_tin_user(du_lieu_economy, str(user_id))
                thong_tin_user["xu"] = thong_tin_user.get("xu", 0) + reward
                du_lieu_economy[str(user_id)] = thong_tin_user
                ghi_json(ECONOMY_FILE, du_lieu_economy)

                game["completed"] = True
                cooldown_until = now + timedelta(seconds=MINIGAME_COOLDOWN_SECONDS)
                data.setdefault("cooldowns", {})[str(user_id)] = _minigame_iso(cooldown_until)
                data["games"].pop(game_id, None)
                ghi_json(MINIGAME_FILE, data)

                return jsonify({
                    "symbol": "⭐",
                    "special": True,
                    "completed": True,
                    "reward": reward,
                    "tong_xu": thong_tin_user["xu"],
                    "cooldown_seconds": MINIGAME_COOLDOWN_SECONDS,
                    "matched_indices": game.get("matched_indices", []),
                })

            ghi_json(MINIGAME_FILE, data)
            return jsonify({
                "symbol": "⭐",
                "special": True,
                "completed": False,
            })

        # Nếu chưa có ô thứ nhất.
        if not revealed:
            game["revealed_indices"] = [index]
            ghi_json(MINIGAME_FILE, data)
            return jsonify({
                "symbol": board[index],
                "completed": False,
            })

        # Đã có ô thứ nhất, đây là ô thứ hai.
        first_index = revealed[0]
        first_symbol = board[first_index]
        second_symbol = board[index]

        game["revealed_indices"] = []

        if first_symbol == second_symbol:
            matched = [int(x) for x in game.get("matched_indices", [])]
            matched.extend([first_index, index])
            game["matched_indices"] = matched

            da_xong = len(matched) == cfg["pair_count"] * 2
            if da_xong and (game.get("mode") != "easy" or game.get("special_revealed")):
                reward = random.randint(cfg["reward_min"], cfg["reward_max"])

                du_lieu_economy = doc_json(ECONOMY_FILE, {})
                thong_tin_user = lay_thong_tin_user(du_lieu_economy, str(user_id))
                thong_tin_user["xu"] = thong_tin_user.get("xu", 0) + reward
                du_lieu_economy[str(user_id)] = thong_tin_user
                ghi_json(ECONOMY_FILE, du_lieu_economy)

                cooldown_until = now + timedelta(seconds=MINIGAME_COOLDOWN_SECONDS)
                data.setdefault("cooldowns", {})[str(user_id)] = _minigame_iso(cooldown_until)
                data["games"].pop(game_id, None)
                ghi_json(MINIGAME_FILE, data)

                return jsonify({
                    "symbol": second_symbol,
                    "first_index": first_index,
                    "second_index": index,
                    "first_symbol": first_symbol,
                    "second_symbol": second_symbol,
                    "matched": True,
                    "completed": True,
                    "reward": reward,
                    "tong_xu": thong_tin_user["xu"],
                    "cooldown_seconds": MINIGAME_COOLDOWN_SECONDS,
                    "matched_indices": matched,
                })

            ghi_json(MINIGAME_FILE, data)
            return jsonify({
                "symbol": second_symbol,
                "first_index": first_index,
                "second_index": index,
                "first_symbol": first_symbol,
                "second_symbol": second_symbol,
                "matched": True,
                "completed": False,
                "matched_indices": matched,
            })

        # Không khớp.
        ghi_json(MINIGAME_FILE, data)
        return jsonify({
            "symbol": second_symbol,
            "first_index": first_index,
            "second_index": index,
            "first_symbol": first_symbol,
            "second_symbol": second_symbol,
            "matched": False,
            "completed": False,
        })


# ============ CHẠY BOT ============
if __name__ == "__main__":
    if not TOKEN:
        print("Chưa có DISCORD_TOKEN. Hãy tạo file .env và điền TOKEN vào.")
    else:
        Thread(target=chay_flask).start()
        bot.run(TOKEN)